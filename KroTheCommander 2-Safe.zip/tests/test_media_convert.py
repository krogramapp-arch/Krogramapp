"""Real ffmpeg tests for the conversion helpers (skipped if ffmpeg is missing). No Telegram, no network."""
import asyncio
import importlib.util
import os
import shutil
import subprocess
import tempfile
import types
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location("media_convert", os.path.join(ROOT, "sbb_b/helpers/media_convert.py"))
mc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mc)

HAVE = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


def fake(**attrs):
    base = dict(sticker=None, video_note=None, gif=None, voice=None, audio=None, video=None, photo=None,
                file=types.SimpleNamespace(mime_type=attrs.pop("mime", None)))
    base.update(attrs)
    return types.SimpleNamespace(**base)


class Classify(unittest.TestCase):
    def test_kinds(self):
        self.assertEqual(mc.classify(fake(sticker=1, mime="image/webp")), "sticker")
        self.assertEqual(mc.classify(fake(sticker=1, mime="video/webm")), "sticker_video")
        self.assertEqual(mc.classify(fake(sticker=1, mime="application/x-tgsticker")), "tgs")
        self.assertEqual(mc.classify(fake(video_note=1)), "video_note")
        self.assertEqual(mc.classify(fake(gif=1, video=1)), "gif")
        self.assertEqual(mc.classify(fake(voice=1, audio=1)), "voice")
        self.assertEqual(mc.classify(fake(audio=1)), "audio")
        self.assertEqual(mc.classify(fake(video=1)), "video")
        self.assertEqual(mc.classify(fake(photo=1)), "photo")
        self.assertIsNone(mc.classify(fake()))
        self.assertIsNone(mc.classify(None))

    def test_targets(self):
        with self.assertRaises(mc.ConvertError):
            mc.check_target("tgs", "video")
        with self.assertRaises(mc.ConvertError):
            mc.check_target("audio", "image")
        with self.assertRaises(mc.ConvertError):
            mc.check_target("photo", "audio")
        mc.check_target("video", "audio")
        mc.check_target("sticker", "image")


@unittest.skipUnless(HAVE, "ffmpeg not installed")
class RealFfmpeg(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.d = tempfile.mkdtemp()
        j = lambda n: os.path.join(cls.d, n)
        run = lambda *a: subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *a], check=True)
        run("-f", "lavfi", "-i", "testsrc=size=321x241:rate=25:duration=4", "-f", "lavfi", "-i",
            "sine=frequency=440:duration=4", "-shortest", "-c:v", "ffv1", "-c:a", "pcm_s16le", j("v.mkv"))
        run("-f", "lavfi", "-i", "testsrc=size=200x100:rate=10:duration=2", "-pix_fmt", "yuv420p", j("silent.mp4"))
        run("-f", "lavfi", "-i", "sine=frequency=300:duration=3", j("a.mp3"))
        run("-f", "lavfi", "-i", "testsrc=size=640x480:duration=1", "-frames:v", "1", j("p.png"))
        cls.j = staticmethod(j)

    def go(self, coro):
        return asyncio.run(coro)

    def probe(self, p):
        return self.go(mc.probe(p))

    def test_video_from_video_and_photo(self):
        info = self.probe(self.j("v.mkv"))
        out = self.go(mc.to_video(self.j("v.mkv"), self.j("o1.mp4"), "video", info))
        pi = self.probe(out)
        self.assertEqual((pi["width"] % 2, pi["height"] % 2), (0, 0))
        self.assertTrue(pi["has_audio"])
        pinfo = self.probe(self.j("p.png"))
        out = self.go(mc.to_video(self.j("p.png"), self.j("o2.mp4"), "photo", pinfo))
        self.assertTrue(self.probe(out)["has_video"])

    def test_gif_is_silent(self):
        info = self.probe(self.j("v.mkv"))
        out = self.go(mc.to_gif(self.j("v.mkv"), self.j("o3.mp4"), "video", info))
        self.assertFalse(self.probe(out)["has_audio"])

    def test_image_from_video_and_png(self):
        info = self.probe(self.j("v.mkv"))
        out = self.go(mc.to_image(self.j("v.mkv"), self.j("o4.png"), "video", info))
        self.assertGreater(os.path.getsize(out), 0)
        out = self.go(mc.to_image(self.j("p.png"), self.j("o5.jpg"), "photo", self.probe(self.j("p.png"))))
        self.assertGreater(os.path.getsize(out), 0)

    def test_audio_and_voice(self):
        info = self.probe(self.j("v.mkv"))
        a = self.go(mc.to_audio(self.j("v.mkv"), self.j("o6.mp3"), "video", info))
        self.assertTrue(self.probe(a)["has_audio"])
        v = self.go(mc.to_voice(self.j("v.mkv"), self.j("o7.ogg"), "video", info))
        self.assertTrue(self.probe(v)["has_audio"])
        with self.assertRaises(mc.ConvertError):
            self.go(mc.to_audio(self.j("silent.mp4"), self.j("o8.mp3"), "video", self.probe(self.j("silent.mp4"))))

    def test_video_note_is_square_384(self):
        info = self.probe(self.j("v.mkv"))
        out = self.go(mc.to_video_note(self.j("v.mkv"), self.j("o9.mp4"), "video", info))
        pi = self.probe(out)
        self.assertEqual((pi["width"], pi["height"]), (384, 384))

    def test_stickers(self):
        info = self.probe(self.j("p.png"))
        out = self.go(mc.to_sticker(self.j("p.png"), self.j("s1"), "photo", info))
        self.assertTrue(out.endswith(".webp"))
        pi = self.probe(out)
        self.assertEqual(max(pi["width"], pi["height"]), 512)
        vinfo = self.probe(self.j("v.mkv"))
        out = self.go(mc.to_sticker(self.j("v.mkv"), self.j("s2"), "video", vinfo))
        self.assertTrue(out.endswith(".webm"))
        self.assertLessEqual(os.path.getsize(out), mc.STICKER_MAX)
        self.assertLessEqual(self.probe(out)["duration"], 3.2)

    def test_filename_with_quotes_and_spaces_is_safe(self):
        weird = self.j("we ird ' name; echo hacked.mp4")
        shutil.copy(self.j("v.mkv"), weird)
        info = self.probe(weird)
        out = self.go(mc.to_image(weird, self.j("o10.png"), "video", info))
        self.assertTrue(os.path.exists(out))
        self.assertFalse(os.path.exists(os.path.join(self.d, "hacked")))


if __name__ == "__main__":
    unittest.main()
