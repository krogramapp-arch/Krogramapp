"""اختبارات KroTheCommander (unittest). تشغيل: python -m unittest discover -s tests -v

الاختبارات الثابتة والحسابية تعمل بدون Telethon. اختبارات قاعدة البيانات تتخطى اذا لم يكن sqlalchemy مثبتا.
لا تتصل هذه الاختبارات بتيليجرام ولا بالشبكة.
"""
import ast
import asyncio
import importlib.util
import os
import re
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY_FILES = []
for base, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git", "tests")]
    PY_FILES += [os.path.join(base, f) for f in files if f.endswith(".py")]


def _load(relpath, name):
    spec = importlib.util.spec_from_file_location(name, os.path.join(ROOT, relpath))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


class StaticSecurity(unittest.TestCase):
    def test_all_files_compile(self):
        import warnings

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            for p in PY_FILES:
                ast.parse(_read(p), filename=p)

    def test_no_eval_exec_or_shell(self):
        pat = re.compile(r"(?<![\w.])(eval|exec)\s*\(|os\.system|subprocess\.(call|run|Popen)|shell\s*=\s*True|create_subprocess_shell")
        bad = [p for p in PY_FILES if pat.search(_read(p))]
        self.assertEqual(bad, [])

    def test_no_hardcoded_developer_ids_or_hidden_join(self):
        bad = []
        for p in PY_FILES:
            s = _read(p)
            if re.search(r"1280124974|1694386561|2034443585|673936943|VHdIUHd6RlpkYkNJR1duTg", s):
                bad.append(p)
            if "ImportChatInviteRequest" in s and "base64" in s:
                bad.append(p)
        self.assertEqual(bad, [])

    def test_no_runtime_pip_or_git_update(self):
        pat = re.compile(r"pip3? install|git\.Repo|\.pull\(|git clone")
        bad = [p for p in PY_FILES if pat.search(_read(p)) and "test_security" not in p]
        self.assertEqual(bad, [])

    def test_no_secrets_committed(self):
        pat = re.compile(r"\b\d{7,}:[A-Za-z0-9_-]{30,}\b|\b[0-9a-f]{32}\b|1[A-Za-z0-9_-]{200,}")
        bad = []
        for p in PY_FILES:
            text = "\n".join(l for l in _read(p).splitlines() if "http" not in l)
            if pat.search(text):
                bad.append(os.path.relpath(p, ROOT))
        self.assertEqual(bad, [], "قد تحتوي هذه الملفات على اسرار او هاشات")

    def test_session_not_printed_or_exposed(self):
        for p in PY_FILES:
            s = _read(p)
            if "generate_session" in p:
                continue
            self.assertNotRegex(s, r"(print|LOGS?\.\w+)\([^)\n]*STRING_SESSION")

    def test_outbound_secret_guard_is_wired_to_telegram_client(self):
        client = _read(os.path.join(ROOT, "sbb_b", "core", "client.py"))
        for method in ("send_message", "send_file", "edit_message", "forward_messages", "__call__"):
            self.assertIn(f"async def {method}(", client)
        self.assertIn("assert_safe_outbound(", client)
        self.assertIn("assert_safe_file_outbound(", client)

    def test_sensitive_messages_are_not_copied_to_botlog(self):
        events = _read(os.path.join(ROOT, "sbb_b", "core", "events.py"))
        self.assertIn("assert_safe_outbound(", events)
        self.assertNotIn("msg = f\"- عذرا لا يمكنني ارسال", events)
        self.assertNotIn("message=msg,\n                send_as=send_as", events)

    def test_telegraph_authorization_is_owner_only(self):
        plugin = _read(os.path.join(ROOT, "sbb_b", "plugins", "التلكراف.py"))
        self.assertIn("event.chat_id != owner.id", plugin)
        self.assertIn('send_message(\n        "me"', plugin)
        self.assertNotIn("BOTLOG_CHATID", plugin)

    def test_commands_are_outgoing_only(self):
        s = _read(os.path.join(ROOT, "sbb_b/core/client.py"))
        self.assertIn("outgoing=True", s)

    def test_external_paste_disabled_by_default(self):
        s = _read(os.path.join(ROOT, "sample_config.py"))
        self.assertIn('"ALLOW_EXTERNAL_PASTE", "false"', s)

    def test_env_example_has_required_names_only(self):
        s = _read(os.path.join(ROOT, ".env.example"))
        for name in ("API_ID", "API_HASH", "SESSION_STRING", "OWNER_ID", "DB_PATH", "COMMAND_PREFIX"):
            self.assertRegex(s, re.compile(rf"^{name}=", re.M))

    def test_requirements_have_no_vcs_or_dropped_packages(self):
        s = _read(os.path.join(ROOT, "requirements.txt"))
        self.assertNotIn("git+", s)
        for dead in ("heroku3", "psycopg2", "motor", "gitpython", "PyGithub"):
            self.assertNotIn(dead, s.lower().replace("pygithub", "PyGithub") if dead == "PyGithub" else s.lower())


class SafeMath(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.calc = staticmethod(_load("sbb_b/helpers/utils/safe_math.py", "safe_math").safe_calc)

    def test_valid(self):
        self.assertEqual(self.calc("2+3*4"), 14)
        self.assertEqual(self.calc("(1+2)*3"), 9)
        self.assertEqual(self.calc("-5+2"), -3)
        self.assertAlmostEqual(self.calc("10/4"), 2.5)

    def test_rejects_code(self):
        for bad in ("__import__('os').system('id')", "open('/etc/passwd')", "1 if 1 else 2",
                    "[1][0]", "2**9999999", "a+1", "lambda:1", "'a'*9", "1;2", ""):
            with self.assertRaises(Exception, msg=bad):
                self.calc(bad)

    def test_length_limit(self):
        with self.assertRaises(ValueError):
            self.calc("1+" * 100 + "1")


class RunCmd(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        src = _read(os.path.join(ROOT, "sbb_b/helpers/utils/utils.py")).replace(
            "from ...core.logger import logging", "import logging"
        )
        cls.mod = type(sys)("u")
        exec(compile(src, "utils_under_test", "exec"), cls.mod.__dict__)  # noqa: S102 (اختبار فقط)

    def test_no_shell_injection(self):
        out = asyncio.run(self.mod.runcmd("echo hello; echo INJECTED"))
        self.assertEqual(out[0], "hello; echo INJECTED")

    def test_invalid_quote_is_handled(self):
        out = asyncio.run(self.mod.runcmd("echo 'unterminated"))
        self.assertEqual(out[2], 1)

    def test_timeout_kills_process(self):
        self.mod.RUNCMD_TIMEOUT = 1
        out = asyncio.run(self.mod.runcmd("sleep 5"))
        self.assertEqual(out[2], 124)


class Database(unittest.TestCase):
    def test_sqlite_roundtrip_and_persistence(self):
        try:
            from sqlalchemy import Column, String, create_engine
            from sqlalchemy.ext.declarative import declarative_base
            from sqlalchemy.orm import sessionmaker
        except ImportError:
            self.skipTest("sqlalchemy غير مثبت في بيئة الاختبار")
        Base = declarative_base()

        class Item(Base):
            __tablename__ = "t"
            k = Column(String, primary_key=True)
            v = Column(String)

        path = os.path.join(tempfile.mkdtemp(), "t.db")
        for round_ in (1, 2):  # المرة الثانية تمثل اعادة التشغيل
            eng = create_engine("sqlite:///" + path)
            Base.metadata.create_all(eng)
            S = sessionmaker(bind=eng)()
            if round_ == 1:
                S.add(Item(k="a", v="x'; DROP TABLE t;--"))
                S.commit()
            else:
                self.assertEqual(S.query(Item).get("a").v, "x'; DROP TABLE t;--")
            S.close()
            eng.dispose()


if __name__ == "__main__":
    unittest.main()
