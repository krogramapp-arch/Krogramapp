import importlib.util
import os
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPEC = importlib.util.spec_from_file_location(
    "outbound_guard", os.path.join(ROOT, "sbb_b", "core", "outbound_guard.py")
)
GUARD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(GUARD)


class OutboundGuardTests(unittest.TestCase):
    def test_broadcast_messages_without_secrets_are_allowed(self):
        GUARD.assert_safe_outbound(
            -100123,
            "Announcement: meeting starts at 5",
            owner_id=123,
            self_id=123,
        )

    def test_blocks_known_account_secrets_to_other_recipients(self):
        with self.assertRaises(GUARD.SensitiveDataBlocked):
            GUARD.assert_safe_outbound(
                -100123,
                "session=private-session-value",
                owner_id=123,
                self_id=123,
                secrets=("private-session-value",),
            )

    def test_blocks_telegram_session_and_bot_token_patterns(self):
        session = "1" + "A" * 220
        bot_token = "12345678:" + "A" * 40
        self.assertTrue(GUARD.contains_sensitive_data(session))
        self.assertTrue(GUARD.contains_sensitive_data(bot_token))

    def test_sensitive_data_may_only_be_sent_to_account_owner(self):
        GUARD.assert_safe_outbound(
            "me",
            "session=private-session-value",
            owner_id=123,
            self_id=123,
            secrets=("private-session-value",),
        )
        with self.assertRaises(GUARD.SensitiveDataBlocked):
            GUARD.assert_safe_outbound(
                "me",
                "session=private-session-value",
                owner_id=123,
                self_id=456,
                secrets=("private-session-value",),
            )

    def test_unknown_entity_types_are_not_assumed_to_be_saved_messages(self):
        class GroupPeer:
            id = 123

        with self.assertRaises(GUARD.SensitiveDataBlocked):
            GUARD.assert_safe_outbound(
                GroupPeer(),
                "session=private-session-value",
                owner_id=123,
                self_id=123,
                secrets=("private-session-value",),
            )

    def test_blocks_session_files_but_allows_normal_media(self):
        with self.assertRaises(GUARD.SensitiveDataBlocked):
            GUARD.assert_safe_file_outbound(
                456,
                "account.session",
                owner_id=123,
                self_id=123,
            )
        GUARD.assert_safe_file_outbound(
            456,
            "holiday.jpg",
            owner_id=123,
            self_id=123,
        )

    def test_scans_text_files_before_upload(self):
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "settings.txt")
            with open(path, "w", encoding="utf-8") as output:
                output.write("API_HASH=private-value")
            with self.assertRaises(GUARD.SensitiveDataBlocked):
                GUARD.assert_safe_file_outbound(
                    456,
                    path,
                    owner_id=123,
                    self_id=123,
                )


if __name__ == "__main__":
    unittest.main()
