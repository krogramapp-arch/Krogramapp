"""Test harness: loads plugin files with fake Telethon/Config so handlers can run without Telegram."""
import asyncio
import importlib
import importlib.util
import os
import re
import sys
import tempfile
import types
from unittest import mock

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TMP = tempfile.mkdtemp(prefix="kro_tests_")
os.environ["TMP_DOWNLOAD_DIRECTORY"] = os.path.join(TMP, "downloads")


class FakeStatus:
    def __init__(self, log):
        self.log = log

    async def edit(self, text, **kw):
        self.log.append(("edit", text))
        return self

    async def delete(self):
        self.log.append(("delete", None))


class FakeClient:
    def __init__(self):
        self.sent = []

    async def send_file(self, chat, file, **kw):
        self.sent.append((chat, file, kw))
        if isinstance(file, str):
            assert os.path.exists(file), "file must exist when sending"

    async def inline_query(self, bot, q):
        raise RuntimeError("inline disabled in tests")


class FakeEvent:
    def __init__(self, client, pattern, text, reply=None, chat_id=-100, eid=7):
        self.client, self.chat_id, self.id, self.raw_text = client, chat_id, eid, text
        self.reply_to_msg_id = None
        self._reply = reply
        self.log = []
        m = re.match("^" + pattern, text)
        self.pattern_match = m

    async def get_reply_message(self):
        return self._reply

    async def reply(self, text, **kw):
        self.log.append(("reply", text))
        return FakeStatus(self.log)

    async def edit(self, text, **kw):
        self.log.append(("edit", text))
        return FakeStatus(self.log)


def load_plugin(filename, gvars=None):
    """Returns (module, patterns{funcname: pattern})."""
    patterns = {}
    gv = gvars if gvars is not None else {}

    def ar_cmd(**kw):
        def deco(fn):
            patterns[fn.__name__] = kw.get("pattern")
            return fn
        return deco

    def on(*a, **k):
        def deco(fn):
            patterns[fn.__name__] = "<event>"
            return fn
        return deco

    fake_userbot = types.SimpleNamespace(ar_cmd=ar_cmd, on=on, tgbot=mock.MagicMock())

    def pkg(name, path=None):
        m = types.ModuleType(name)
        m.__path__ = [path] if path else []
        sys.modules[name] = m
        return m

    base = os.path.join(ROOT, "sbb_b")
    root = pkg("sbb_b", base)
    root.sbb_b = fake_userbot
    pkg("sbb_b.helpers", os.path.join(base, "helpers"))
    pkg("sbb_b.plugins", os.path.join(base, "plugins"))
    pkg("sbb_b.core")
    pkg("sbb_b.sql_helper")
    cfg = pkg("sbb_b.Config")
    cfg.Config = types.SimpleNamespace(TMP_DOWNLOAD_DIRECTORY=os.environ["TMP_DOWNLOAD_DIRECTORY"],
                                       TG_BOT_USERNAME="@kro_bot", OWNER_ID=1)
    lg = pkg("sbb_b.core.logger")
    import logging
    lg.logging = logging
    mg = pkg("sbb_b.core.managers")

    async def edit_or_reply(event, text, *a, **k):
        return await event.edit(text)

    async def edit_delete(event, text, *a, **k):
        return await event.edit(text)

    mg.edit_or_reply, mg.edit_delete = edit_or_reply, edit_delete
    gl = pkg("sbb_b.sql_helper.globals")
    gl.gvarstatus = lambda k: gv.get(k)
    gl.addgvar = lambda k, v: gv.__setitem__(k, v)

    try:
        import aiohttp  # noqa: F401
    except ImportError:  # not installed in the sandbox: network code is never executed in these tests
        sys.modules["aiohttp"] = mock.MagicMock()
    tl = mock.MagicMock()
    sys.modules["telethon"] = tl
    sys.modules["telethon.errors"] = mock.MagicMock()
    for name in [m for m in list(sys.modules) if m.startswith("sbb_b.helpers.")]:
        sys.modules.pop(name)
    path = os.path.join(base, "plugins", filename)
    spec = importlib.util.spec_from_file_location("sbb_b.plugins." + filename[:-3], path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod, patterns


def run(coro):
    return asyncio.run(coro)
