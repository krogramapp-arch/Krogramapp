import importlib.util
import os
import time
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location("dl_common", os.path.join(ROOT, "sbb_b/helpers/dl_common.py"))
dc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dc)


class UrlSafety(unittest.TestCase):
    def test_services(self):
        cases = {
            "https://www.youtube.com/watch?v=abc": "youtube",
            "https://youtu.be/abc": "youtube",
            "https://m.youtube.com/watch?v=1": "youtube",
            "https://soundcloud.com/a/b": "soundcloud",
            "https://vm.tiktok.com/ZM123/": "tiktok",
            "https://www.instagram.com/reel/Cxyz/": "instagram",
            "https://fb.watch/abc/": "facebook",
            "https://www.facebook.com/user/videos/123": "facebook",
        }
        for url, svc in cases.items():
            self.assertEqual(dc.service_of(url), svc, url)

    def test_rejects_hostile_urls(self):
        bad = [
            "file:///etc/passwd", "http://localhost/x", "http://127.0.0.1:8080/", "http://169.254.169.254/latest",
            "https://youtube.com.evil.com/x", "https://evil.com/youtube.com", "https://notyoutube.com/",
            "https://youtube.com@evil.com/", "https://user:pw@youtube.com/", "https://youtube.com:8443/x",
            "ftp://youtube.com/x", "javascript:alert(1)", "", "youtube.com/watch?v=1",
        ]
        for url in bad:
            self.assertIsNone(dc.service_of(url), url)

    def test_only_url(self):
        self.assertEqual(dc.only_url("  https://vm.tiktok.com/ZM1/ "), "https://vm.tiktok.com/ZM1/")
        self.assertIsNone(dc.only_url("look https://vm.tiktok.com/ZM1/"))
        self.assertIsNone(dc.only_url("https://a.com/x https://b.com/y"))

    def test_auto_kind(self):
        self.assertEqual(dc.auto_kind("https://www.tiktok.com/@u/video/123"), "tiktok")
        self.assertEqual(dc.auto_kind("https://vt.tiktok.com/ZS1/"), "tiktok")
        self.assertIsNone(dc.auto_kind("https://www.tiktok.com/@u"))
        self.assertEqual(dc.auto_kind("https://www.instagram.com/p/Cabc_1/"), "instagram")
        self.assertEqual(dc.auto_kind("https://www.instagram.com/reel/Cabc/?igsh=1"), "instagram")
        self.assertIsNone(dc.auto_kind("https://www.instagram.com/someuser/"))
        self.assertIsNone(dc.auto_kind("https://www.instagram.com/stories/u/123/"))
        self.assertEqual(dc.auto_kind("https://fb.watch/xyz/"), "facebook")
        self.assertEqual(dc.auto_kind("https://www.facebook.com/watch/?v=123"), "facebook")
        self.assertIsNone(dc.auto_kind("https://www.facebook.com/someprofile"))
        self.assertIsNone(dc.auto_kind("https://www.youtube.com/watch?v=1"))

    def test_image_hosts(self):
        self.assertTrue(dc.is_image_host("https://scontent-x.cdninstagram.com/a.jpg"))
        self.assertFalse(dc.is_image_host("http://scontent.cdninstagram.com/a.jpg"))
        self.assertFalse(dc.is_image_host("https://cdninstagram.com.evil.io/a.jpg"))


class Helpers(unittest.TestCase):
    def test_usernames(self):
        self.assertEqual(dc.clean_username("@some.user_1", "tiktok"), "some.user_1")
        self.assertEqual(dc.clean_username("https://www.tiktok.com/@abc", "tiktok"), "abc")
        self.assertEqual(dc.clean_username("https://instagram.com/abc/", "instagram"), "abc")
        for bad in ("a b", "x;rm -rf", "../etc", "", "a" * 40, "https://www.tiktok.com/@a/video/1"):
            self.assertIsNone(dc.clean_username(bad, "tiktok"), bad)

    def test_tiktok_date(self):
        d = dc.tiktok_date_from_id(7000000000000000000 | 0)  # ts = id >> 32
        self.assertIsNotNone(d)
        self.assertIsNone(dc.tiktok_date_from_id("abc"))
        self.assertIsNone(dc.tiktok_date_from_id(5))

    def test_format(self):
        self.assertEqual(dc.fmt_duration(3725), "1:02:05")
        self.assertEqual(dc.fmt_duration(65), "1:05")
        self.assertEqual(dc.human_number(1234567), "1,234,567")
        self.assertEqual(dc.human_size(1536), "1.5 KB")

    def test_token_store_ttl_and_cap(self):
        s = dc.TokenStore(ttl=0.05, cap=3)
        toks = [s.put(i) for i in range(5)]
        self.assertLessEqual(len(s._d), 3)
        self.assertIsNone(s.get(toks[0]))
        t = s.put("x")
        self.assertEqual(s.get(t), "x")
        time.sleep(0.07)
        self.assertIsNone(s.get(t))


if __name__ == "__main__":
    unittest.main()
