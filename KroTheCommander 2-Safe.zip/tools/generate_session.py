"""توليد SESSION_STRING محليا فقط.

يعمل على جهازك. لا يرسل شيئا لاي جهة غير خوادم تيليجرام الرسمية، ولا يكتب الجلسة في ملف.
الاستخدام:  API_ID=... API_HASH=... python tools/generate_session.py
استخدم حسابا تجريبيا اولا. لا تشارك الناتج مع احد.
"""
import asyncio
import os
import sys

from telethon import TelegramClient
from telethon.sessions import StringSession


async def main():
    try:
        api_id = int(os.environ["API_ID"])
        api_hash = os.environ["API_HASH"]
    except (KeyError, ValueError):
        sys.exit("حدد API_ID و API_HASH كمتغيرات بيئة")
    async with TelegramClient(StringSession(), api_id, api_hash) as client:
        print("\nSESSION_STRING (تعامل معها ككلمة مرور):\n")
        print(client.session.save())


asyncio.run(main())
