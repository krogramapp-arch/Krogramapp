# Copyright & License Notice

KroTheCommander is a modified fork of JMTHON, which itself built on open-source foundations (UniBorg, etc.).
All original author notices remain in file headers and LICENSE. This file does not replace those.

**License:** GNU AGPL-3.0 (see LICENSE file for full text)

**Modified by:** @krofullpower (Channel: @dlxfullpower)  
**Original Authors:** As credited in individual files and the JMTHON project  

## AGPL-3.0 Obligations (simplified, not legal advice)

1. **Preserve Notices:** Copyrights and license text must remain in all distributed copies.
2. **Disclose Changes:** Modified files must be marked as such with the modification date/author.
3. **Share Source:** If you distribute this to others (including via hosting), provide source code under the same license.
4. **Attribution:** Preserve original author names. Don't claim credit for their work.
5. **Network Distribution:** If this runs as a service for others, they can request the source.

## For Users

- If you host this as a bot for others: provide them access to source code.
- If you modify it: keep the license and credit the original authors.
- You can use this for personal automation on your Telegram account.

## Key Files

- `LICENSE` – Full AGPL-3.0 text
- `NOTICE.md` – This file
- File headers – Original author credits (preserved)
- `CHANGES.md` – What was modified in this fork
- `SECURITY_REPORT.md` – Security review notes

---

No warranty. Use at your own responsibility.
