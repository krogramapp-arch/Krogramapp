# KroTheCommander

A Telegram userbot (self-bot) built on Telethon, modified from the JMTHON open-source project.

**Developer:** @krofullpower  
**Channel:** @dlxfullpower  
**License:** GNU AGPL-3.0 (see LICENSE and NOTICE.md)

## Features

### Download & Search
- **search <name or link>** – Search YouTube, choose format (video/audio)
- **yout <name or link>** – Download YouTube audio directly
- **soundcloud <name or link>** – Search SoundCloud with format options
- **tiktok <username or link>** – TikTok account info (followers, verified status, etc.)
- **instagram <username or link>** – Instagram profile info with high-res avatar
- **(TikTok/Instagram/Facebook link)** – Auto-download in groups
- **shazam** (reply to audio) – Identify song: title, artist, album

### Media Conversion (reply to sticker/GIF/video/audio/photo, then use command)
- **تحويل فيديو** → MP4 video
- **تحويل متحركة** → Silent GIF (mp4)
- **تحويل صورة** → Image (frame or sticker to picture)
- **تحويل صوت** → MP3 audio file
- **تحويل فويس** → Voice message (opus)
- **تحويل ملصق** → Sticker (webp, or webm for animated)
- **تحويل فيديو نوت** → Round video note (384×384, max 60s)

## Installation

### Local Setup
```bash
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your API_ID, API_HASH, SESSION_STRING, OWNER_ID, TG_BOT_TOKEN
python3 -m sbb_b
```

### Generate Session String
On your local machine only:
```bash
pip install telethon
API_ID=... API_HASH=... python tools/generate_session.py
```
Copy the output to SESSION_STRING in .env. **Never share this token.**

### Railway Deployment
1. Fork this repo (private)
2. Create a new Service from GitHub
3. Set environment variables in Variables
4. Attach a Volume at `/app/data` with `DB_PATH=/app/data/kro.db`
5. Use the included `Procfile` (`worker: python3 -m sbb_b`) as the start command

### Replit
1. Set secrets in the Secrets panel
2. Run: `pip install -r requirements.txt && python3 -m sbb_b`

## Environment Variables

| Variable | Required | Default | Notes |
|---|---|---|---|
| API_ID | Yes | - | From my.telegram.org |
| API_HASH | Yes | - | From my.telegram.org |
| SESSION_STRING | Yes | - | Treat as password |
| OWNER_ID | No | - | Auto-detect if empty |
| TG_BOT_TOKEN | Yes | - | Bot token from BotFather |
| DB_PATH | No | data/kro.db | SQLite database |
| COMMAND_PREFIX | No | . | Command prefix |
| ALLOW_EXTERNAL_PASTE | No | false | Allow spaceb.in uploads |
| COMMAND_COOLDOWN | No | 1.0 | Seconds between commands |
| MAX_CONCURRENT_COMMANDS | No | 4 | Parallel command limit |
| PRIVATE_GROUP_BOT_API_ID | No | - | Log group (optional) |

`OWNER_ID` must identify the account running this userbot. Sensitive-data
exceptions are limited to Telegram's Saved Messages target (`"me"`); an
unknown or unverified target is never treated as the owner.

## Safety Notes

- Commands work only on your outgoing messages. Other accounts can't trigger them unless you enable sudo mode (disabled by default).
- No auto-code updates, no runtime package installation, no secret auto-login to channels.
- Error logs are local only. Secrets in known env var names are masked in logs.
- Session strings are permanent account access tokens. Never share or commit them.
- Outgoing messages and edits are checked for configured credentials, Telegram session strings, bot tokens, Telegraph authorization links, and credential-bearing text/session files. Detected sensitive content is blocked from other chats; ordinary user-initiated broadcasts remain available.
- The Telegraph account authorization link is sent only to the account owner's Saved Messages, and the Telegraph command is restricted to Saved Messages.

## Testing

```bash
python -m unittest discover -s tests -v
```

## Stopping & Backup

Send SIGTERM to the process for clean shutdown. Close all Telegram connections and database.

To backup: copy the DB file (DB_PATH and its `-wal` / `-shm` siblings) after shutdown.

## Known Limitations

- TGS (animated TGS) stickers cannot be converted
- Large files (>200 MB by default) are skipped
- Videos >1 hour are skipped (configureable)
- TikTok/Instagram profile fetching requires network access

## Credits

**Original Authors:** JMTHON project and contributors (see LICENSE)  
**Modified By:** @krofullpower (@dlxfullpower channel)  
**License:** Kept as AGPL-3.0. All changes inherit the same license.

---

**Disclaimer:** Use at your own risk. This is a personal tool for your account. Telegram ToS may change. No warranty.
