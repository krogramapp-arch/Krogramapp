import logging
import re

from ..Config import Config

_SENSITIVE_NAME = re.compile(r"(KEY|TOKEN|SECRET|HASH|SESSION|PASSWORD|CODE|DATA|APPID|CRED)", re.I)
_cache = {"vals": None}


def secret_values():
    """قيم الاسرار الحالية (للاخفاء من السجلات والرسائل). لا تطبع ابدا."""
    if _cache["vals"] is None:
        vals = set()
        for name in dir(Config):
            if name.startswith("_") or not _SENSITIVE_NAME.search(name):
                continue
            value = getattr(Config, name, None)
            if isinstance(value, str) and len(value) >= 6:
                vals.add(value)
        _cache["vals"] = sorted(vals, key=len, reverse=True)
    return _cache["vals"]


def scrub(text):
    """يستبدل اي سر معروف بعبارة محجوب."""
    text = str(text)
    for value in secret_values():
        if value in text:
            text = text.replace(value, "[محجوب]")
    return text


class SecretFilter(logging.Filter):
    def filter(self, record):
        try:
            record.msg = scrub(record.getMessage())
            record.args = ()
        except Exception:
            pass
        return True


logging.basicConfig(
    format="[%(levelname)s- %(asctime)s]- %(name)s- %(message)s",
    level=logging.INFO,
    datefmt="%H:%M:%S",
)
for _handler in logging.getLogger().handlers:
    _handler.addFilter(SecretFilter())
# تقليل الضجيج: مكتبات الشبكة تسجل اكثر من اللازم
for _noisy in ("telethon", "asyncio", "urllib3", "aiohttp", "PIL"):
    logging.getLogger(_noisy).setLevel(logging.WARNING)
