import os
import re
from pathlib import Path
from typing import Iterable


class SensitiveDataBlocked(ValueError):
    """An outbound message contained credentials and was blocked."""


_CREDENTIAL_ASSIGNMENT = re.compile(
    r"(?i)\b(?:api[_-]?hash|session(?:[_-]?string)?|string[_-]?session|"
    r"tg[_-]?bot[_-]?token|bot[_-]?token|access[_-]?token|client[_-]?secret|"
    r"password|two[_-]?step[_-]?verification[_-]?code)\s*[:=]\s*\S+"
)
_TELEGRAM_BOT_TOKEN = re.compile(r"\b\d{7,}:[A-Za-z0-9_-]{30,}\b")
_TELEGRAM_SESSION_STRING = re.compile(r"\b1[A-Za-z0-9_-]{200,}\b")
_TELEGRAPH_AUTH_URL = re.compile(
    r"https?://(?:www\.)?(?:edit\.)?telegra\.ph/auth/[^\s<>\]\)]+",
    re.I,
)
_HEX_SECRET = re.compile(r"\b[0-9a-f]{32}\b", re.I)
_SENSITIVE_FILE_SUFFIXES = {
    ".session",
    ".session-journal",
    ".session-wal",
    ".env",
    ".pem",
    ".key",
    ".p12",
    ".sqlite",
    ".sqlite3",
    ".sqlite-wal",
    ".sqlite-shm",
    ".db",
    ".db-wal",
    ".db-shm",
}
_TEXT_FILE_SUFFIXES = {
    ".cfg",
    ".conf",
    ".config",
    ".csv",
    ".ini",
    ".json",
    ".log",
    ".md",
    ".py",
    ".txt",
    ".xml",
    ".yaml",
    ".yml",
}
_SENSITIVE_NAME_PARTS = ("credential", "secret", "session", "token", "private-key")
_FILE_SCAN_CHUNK_SIZE = 64 * 1024


def configured_secrets(config) -> tuple[str, ...]:
    names = re.compile(r"(?i)(?:session|api_hash|token|secret|password|credential|access_key|verification_code)")
    values = set()
    for name, value in vars(config).items():
        if names.search(name) and isinstance(value, str) and len(value) >= 6:
            values.add(value)
    return tuple(values)


def contains_sensitive_data(value, secrets: Iterable[str] = ()) -> bool:
    text = _extract_text(value)
    if not text:
        return False
    if any(secret and secret in text for secret in secrets):
        return True
    return bool(
        _CREDENTIAL_ASSIGNMENT.search(text)
        or _TELEGRAM_BOT_TOKEN.search(text)
        or _TELEGRAM_SESSION_STRING.search(text)
        or _TELEGRAPH_AUTH_URL.search(text)
        or _HEX_SECRET.search(text)
    )


def assert_safe_outbound(entity, payloads, *, owner_id, self_id, secrets=()):
    if not contains_sensitive_data(payloads, secrets):
        return
    if _is_owner_target(entity, owner_id=owner_id, self_id=self_id):
        return
    raise SensitiveDataBlocked("Outbound message blocked because it contains sensitive account data.")


def assert_safe_file_outbound(entity, files, *, owner_id, self_id, secrets=()):
    if _is_owner_target(entity, owner_id=owner_id, self_id=self_id):
        return
    for file in _as_items(files):
        if _is_sensitive_file(file, secrets):
            raise SensitiveDataBlocked("Outbound file blocked because it may contain sensitive account data.")


def _is_owner_target(entity, *, owner_id, self_id) -> bool:
    if type(entity).__name__ == "InputPeerSelf":
        return bool(owner_id and self_id and owner_id == self_id)
    if isinstance(entity, str) and entity.strip().lower() in {"me", "self"}:
        return bool(owner_id and self_id and owner_id == self_id)
    if isinstance(entity, int):
        return bool(owner_id and entity == owner_id)
    if type(entity).__name__ not in {
        "InputPeerUser",
        "InputPeerUserFromMessage",
        "PeerUser",
        "User",
    }:
        return False
    for attribute in ("user_id", "id"):
        candidate = getattr(entity, attribute, None)
        if isinstance(candidate, int) and owner_id and candidate == owner_id:
            return True
    return False


def _is_sensitive_file(file, secrets) -> bool:
    if isinstance(file, (list, tuple)):
        return any(_is_sensitive_file(item, secrets) for item in file)
    if isinstance(file, (bytes, bytearray, memoryview)):
        return contains_sensitive_data(bytes(file).decode("utf-8", "ignore"), secrets)
    if isinstance(file, os.PathLike):
        path = Path(file)
    elif isinstance(file, str):
        path = Path(file)
    else:
        return False

    name = path.name.lower()
    suffix = path.suffix.lower()
    if suffix in _SENSITIVE_FILE_SUFFIXES or any(part in name for part in _SENSITIVE_NAME_PARTS):
        return True
    try:
        if not path.is_file() or suffix not in _TEXT_FILE_SUFFIXES:
            return False
        overlap = min(max((len(secret) for secret in secrets), default=0), _FILE_SCAN_CHUNK_SIZE)
        overlap = max(overlap, 512)
        with path.open("r", encoding="utf-8", errors="ignore") as source:
            carry = ""
            while chunk := source.read(_FILE_SCAN_CHUNK_SIZE):
                text = carry + chunk
                if contains_sensitive_data(text, secrets):
                    return True
                carry = text[-overlap:]
    except OSError as error:
        raise SensitiveDataBlocked("Unable to inspect an outbound file for sensitive account data.") from error
    return False


def _extract_text(value) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value).decode("utf-8", "ignore")
    if isinstance(value, dict):
        return " ".join(_extract_text(item) for item in value.values())
    if isinstance(value, (list, tuple, set)):
        return " ".join(_extract_text(item) for item in value)
    for attribute in ("raw_text", "message", "text", "caption", "file_name", "name"):
        candidate = getattr(value, attribute, None)
        if isinstance(candidate, (str, bytes, bytearray, memoryview)):
            return _extract_text(candidate)
    return ""


def _as_items(value):
    if isinstance(value, (list, tuple)):
        return value
    return (value,)
