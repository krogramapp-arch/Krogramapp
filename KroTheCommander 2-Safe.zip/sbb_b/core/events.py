import typing

from telethon import events, hints, types
from telethon.tl.types import (
    InputPeerChannel,
    InputPeerChat,
    InputPeerUser,
    MessageMediaWebPage,
)

from ..Config import Config
from .managers import edit_or_reply
from .outbound_guard import (
    assert_safe_file_outbound,
    assert_safe_outbound,
    configured_secrets,
    contains_sensitive_data,
)


@events.common.name_inner_event
class NewMessage(events.NewMessage):
    def __init__(self, require_admin: bool = None, inline: bool = False, **kwargs):
        super().__init__(**kwargs)

        self.require_admin = require_admin
        self.inline = inline

    def filter(self, event):
        _event = super().filter(event)
        if not _event:
            return

        if self.inline is not None and bool(self.inline) != bool(
            event.message.via_bot_id
        ):
            return

        if self.require_admin and not isinstance(event._chat_peer, types.PeerUser):
            is_creator = False
            is_admin = False
            creator = hasattr(event.chat, "creator")
            admin_rights = hasattr(event.chat, "admin_rights")
            flag = None
            if not creator and not admin_rights:
                try:
                    event.chat = event._client.loop.create_task(event.get_chat())
                except AttributeError:
                    flag = "Null"

            if self.incoming:
                try:
                    p = event._client.loop.create_task(
                        event._client.get_permissions(event.chat_id, event.sender_id)
                    )
                    participant = p.participant
                except Exception:
                    participant = None
                if isinstance(participant, types.ChannelParticipantCreator):
                    is_creator = True
                if isinstance(participant, types.ChannelParticipantAdmin):
                    is_admin = True
            elif flag:
                is_admin = True
                is_creator = False
            else:
                is_creator = event.chat.creator
                is_admin = event.chat.admin_rights

            if not is_creator and not is_admin:
                text = "- يجب ان تمتلك صلاحيات المشرف اولا "

                event._client.loop.create_task(edit_or_reply(event, text))
                return
        return event


@events.common.name_inner_event
class MessageEdited(NewMessage):
    @classmethod
    def build(cls, update, others=None, self_id=None):
        if isinstance(update, types.UpdateEditMessage):
            return cls.Event(update.message)
        if isinstance(update, types.UpdateEditChannelMessage):
            if (
                update.message.edit_date
                and update.message.is_channel
                and not update.message.is_group
            ):
                return
            return cls.Event(update.message)

    class Event(NewMessage.Event):
        pass


async def safe_check_text(msg):  # sourcery no-metrics
    if not msg:
        return False
    msg = str(msg)
    from .session import sbb_b

    phone = str((await sbb_b.get_entity(sbb_b.uid)).phone)
    return contains_sensitive_data(
        (msg, phone[-10:]),
        configured_secrets(Config),
    )


async def send_message(
    client,
    entity: "hints.EntityLike",
    message: "hints.MessageLike" = "",
    *,
    send_as: "hints.EntityLike" = None,
    reply_to: "typing.Union[int, types.Message]" = None,
    attributes: "typing.Sequence[types.TypeDocumentAttribute]" = None,
    parse_mode: typing.Optional[str] = (),
    formatting_entities: typing.Optional[typing.List[types.TypeMessageEntity]] = None,
    link_preview: bool = False,
    file: "typing.Union[hints.FileLike, typing.Sequence[hints.FileLike]]" = None,
    thumb: "hints.FileLike" = None,
    force_document: bool = False,
    clear_draft: bool = False,
    buttons: "hints.MarkupLike" = None,
    silent: bool = None,
    album: bool = False,
    allow_cache: bool = False,
    background: bool = None,
    noforwards: bool = None,
    supports_streaming: bool = False,
    schedule: "hints.DateLike" = None,
    comment_to: "typing.Union[int, types.Message]" = None,
):
    chatid = entity
    assert_safe_outbound(
        chatid,
        (message, file),
        owner_id=Config.OWNER_ID,
        self_id=getattr(client, "uid", None),
        secrets=configured_secrets(Config),
    )
    assert_safe_file_outbound(
        chatid,
        file,
        owner_id=Config.OWNER_ID,
        self_id=getattr(client, "uid", None),
        secrets=configured_secrets(Config),
    )
    if str(chatid) in [
        str(Config.BOTLOG_CHATID),
        str(Config.PM_LOGGER_GROUP_ID),
    ]:
        return await client.sendmessage(
            entity=chatid,
            message=message,
            send_as=send_as,
            reply_to=reply_to,
            attributes=attributes,
            parse_mode=parse_mode,
            formatting_entities=formatting_entities,
            link_preview=link_preview,
            file=file,
            thumb=thumb,
            force_document=force_document,
            clear_draft=clear_draft,
            buttons=buttons,
            silent=silent,
            album=album,
            allow_cache=allow_cache,
            background=background,
            noforwards=noforwards,
            supports_streaming=supports_streaming,
            schedule=schedule,
            comment_to=comment_to,
        )
    msg = message
    return await client.sendmessage(
        entity=chatid,
        message=msg,
        send_as=send_as,
        reply_to=reply_to,
        attributes=attributes,
        parse_mode=parse_mode,
        formatting_entities=formatting_entities,
        link_preview=link_preview,
        file=file,
        thumb=thumb,
        force_document=force_document,
        clear_draft=clear_draft,
        buttons=buttons,
        silent=silent,
        album=album,
        allow_cache=allow_cache,
        background=background,
        noforwards=noforwards,
        supports_streaming=supports_streaming,
        schedule=schedule,
        comment_to=comment_to,
    )


async def send_file(
    client,
    entity: "hints.EntityLike",
    file: "typing.Union[hints.FileLike, typing.Sequence[hints.FileLike]]",
    *,
    caption: typing.Union[str, typing.Sequence[str]] = None,
    force_document: bool = False,
    file_size: int = None,
    clear_draft: bool = False,
    progress_callback: "hints.ProgressCallback" = None,
    reply_to: "hints.MessageIDLike" = None,
    attributes: "typing.Sequence[types.TypeDocumentAttribute]" = None,
    thumb: "hints.FileLike" = None,
    allow_cache: bool = True,
    parse_mode: str = (),
    formatting_entities: typing.Optional[typing.List[types.TypeMessageEntity]] = None,
    voice_note: bool = False,
    video_note: bool = False,
    buttons: "hints.MarkupLike" = None,
    silent: bool = None,
    background: bool = None,
    supports_streaming: bool = False,
    schedule: "hints.DateLike" = None,
    comment_to: "typing.Union[int, types.Message]" = None,
    ttl: int = None,
    **kwargs,
):
    assert_safe_outbound(
        entity,
        caption,
        owner_id=Config.OWNER_ID,
        self_id=getattr(client, "uid", None),
        secrets=configured_secrets(Config),
    )
    assert_safe_file_outbound(
        entity,
        file,
        owner_id=Config.OWNER_ID,
        self_id=getattr(client, "uid", None),
        secrets=configured_secrets(Config),
    )
    if isinstance(file, MessageMediaWebPage):
        return await client.send_message(
            entity=entity,
            message=caption,
            reply_to=reply_to,
            parse_mode=parse_mode,
            formatting_entities=formatting_entities,
            link_preview=True,
            buttons=buttons,
            silent=silent,
            schedule=schedule,
            comment_to=comment_to,
        )
    chatid = entity
    if str(chatid) == str(Config.BOTLOG_CHATID):
        return await client.sendfile(
            entity=Config.BOTLOG_CHATID,
            file=file,
            caption=caption,
            force_document=force_document,
            file_size=file_size,
            clear_draft=clear_draft,
            progress_callback=progress_callback,
            reply_to=reply_to,
            attributes=attributes,
            thumb=thumb,
            allow_cache=allow_cache,
            parse_mode=parse_mode,
            formatting_entities=formatting_entities,
            voice_note=voice_note,
            video_note=video_note,
            buttons=buttons,
            silent=silent,
            background=background,
            supports_streaming=supports_streaming,
            schedule=schedule,
            comment_to=comment_to,
            ttl=ttl,
            **kwargs,
        )

    msg = caption
    return await client.sendfile(
        entity=chatid,
        file=file,
        caption=msg,
        force_document=force_document,
        file_size=file_size,
        clear_draft=clear_draft,
        progress_callback=progress_callback,
        reply_to=reply_to,
        attributes=attributes,
        thumb=thumb,
        allow_cache=allow_cache,
        parse_mode=parse_mode,
        formatting_entities=formatting_entities,
        voice_note=voice_note,
        video_note=video_note,
        buttons=buttons,
        silent=silent,
        background=background,
        supports_streaming=supports_streaming,
        schedule=schedule,
        comment_to=comment_to,
        ttl=ttl,
        **kwargs,
    )


async def edit_message(
    client,
    entity: "typing.Union[hints.EntityLike, types.Message]",
    message: "hints.MessageLike" = None,
    text: str = None,
    *,
    parse_mode: str = (),
    attributes: "typing.Sequence[types.TypeDocumentAttribute]" = None,
    formatting_entities: typing.Optional[typing.List[types.TypeMessageEntity]] = None,
    link_preview: bool = True,
    file: "hints.FileLike" = None,
    thumb: "hints.FileLike" = None,
    force_document: bool = False,
    buttons: "hints.MarkupLike" = None,
    supports_streaming: bool = False,
    schedule: "hints.DateLike" = None,
):
    assert_safe_outbound(
        entity,
        (message, text, file),
        owner_id=Config.OWNER_ID,
        self_id=getattr(client, "uid", None),
        secrets=configured_secrets(Config),
    )
    assert_safe_file_outbound(
        entity,
        file,
        owner_id=Config.OWNER_ID,
        self_id=getattr(client, "uid", None),
        secrets=configured_secrets(Config),
    )
    chatid = entity
    if isinstance(chatid, InputPeerChannel):
        chat_id = int(f"-100{str(chatid.channel_id)}")
    elif isinstance(chatid, InputPeerChat):
        chat_id = int(f"-{str(chatid.chat_id)}")
    elif isinstance(chatid, InputPeerUser):
        chat_id = int(chatid.user_id)
    else:
        chat_id = chatid
    if str(chat_id) == str(Config.BOTLOG_CHATID):
        return await client.editmessage(
            entity=chatid,
            message=message,
            text=text,
            parse_mode=parse_mode,
            attributes=attributes,
            formatting_entities=formatting_entities,
            link_preview=link_preview,
            file=file,
            thumb=thumb,
            force_document=force_document,
            buttons=buttons,
            supports_streaming=supports_streaming,
            schedule=schedule,
        )

    main_msg = text
    return await client.editmessage(
        entity=chatid,
        message=message,
        text=main_msg,
        parse_mode=parse_mode,
        attributes=attributes,
        formatting_entities=formatting_entities,
        link_preview=link_preview,
        file=file,
        thumb=thumb,
        force_document=force_document,
        buttons=buttons,
        supports_streaming=supports_streaming,
        schedule=schedule,
    )


# جميع الحقوق خاصه بسورس جمثون
