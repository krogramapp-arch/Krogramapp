import os
import sys

from telethon.network.connection.tcpabridged import ConnectionTcpAbridged

from ..Config import Config
from .bothseesion import bothseesion
from .client import JmthonClient
from .logger import logging, scrub

LOGS = logging.getLogger("KroTheCommander")
__version__ = "2.10.6"

loop = None

if not Config.STRING_SESSION:
    # لا يتم انشاء ملف جلسة تلقائيا ولا طلب تسجيل دخول تفاعلي
    LOGS.error("المتغير SESSION_STRING غير موجود. ولد جلسة بالامر: python tools/generate_session.py")
    sys.exit(1)

session = bothseesion(Config.STRING_SESSION, LOGS)

if not Config.APP_ID or not Config.API_HASH:
    LOGS.error("المتغيران API_ID و API_HASH مطلوبان")
    sys.exit(1)

try:
    sbb_b = JmthonClient(
        session=session,
        api_id=Config.APP_ID,
        api_hash=Config.API_HASH,
        loop=loop,
        app_version=__version__,
        connection=ConnectionTcpAbridged,
        auto_reconnect=True,
        connection_retries=None,
        retry_delay=5,
    )
except Exception as e:
    LOGS.error(scrub(f"كود SESSION_STRING غير صالح: {type(e).__name__}"))
    sys.exit(1)

if not Config.TG_BOT_TOKEN:
    LOGS.error("المتغير TG_BOT_TOKEN مطلوب لتشغيل البوت المساعد (قائمة الاوامر الانلاين)")
    sys.exit(1)

# جلسة البوت المساعد تخزن في مجلد البيانات وتحمى بصلاحيات المالك فقط
_bot_session = os.path.join(os.path.dirname(os.path.abspath(Config.DB_PATH)), "kro_assistant_bot")
os.makedirs(os.path.dirname(_bot_session), exist_ok=True)

sbb_b.tgbot = tgbot = JmthonClient(
    session=_bot_session,
    api_id=Config.APP_ID,
    api_hash=Config.API_HASH,
    loop=loop,
    app_version=__version__,
    connection=ConnectionTcpAbridged,
    auto_reconnect=True,
    connection_retries=None,
    retry_delay=5,
).start(bot_token=Config.TG_BOT_TOKEN)
for _suffix in (".session", ".session-journal"):
    try:
        os.chmod(_bot_session + _suffix, 0o600)
    except OSError:
        pass
