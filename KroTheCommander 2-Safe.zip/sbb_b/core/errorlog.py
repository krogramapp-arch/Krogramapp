"""معالجة الاخطاء محليا: لا يتم رفع اي نص او معرفات الى مواقع خارجية."""
import traceback

from ..Config import Config
from .logger import logging, scrub

LOGS = logging.getLogger("KroTheCommander")


async def report_error(client, exc, command=None):
    """يسجل الخطأ في السجل المحلي، ويرسل ملخصا قصيرا الى مجموعة السجل الخاصة بالمالك فقط اذا كانت مفعلة.

    لا يتضمن الملخص نص رسالة المستخدم ولا معرفات الدردشات ولا مخرجات git.
    """
    LOGS.error(scrub("".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))[-3000:])
    if not getattr(Config, "BOTLOG", False) or not Config.PRIVATE_GROUP_BOT_API_ID:
        return
    try:
        text = "**حدث خطأ اثناء تنفيذ امر**\n"
        if command:
            text += f"الامر: `{scrub(command)[:60]}`\n"
        text += f"نوع الخطأ: `{type(exc).__name__}`\nالتفاصيل: `{scrub(str(exc))[:300]}`"
        await client.send_message(Config.PRIVATE_GROUP_BOT_API_ID, text, link_preview=False)
    except Exception as send_exc:  # فشل الارسال لا يجب ان يوقف السورس
        LOGS.error(scrub(f"تعذر ارسال تقرير الخطأ: {type(send_exc).__name__}"))
