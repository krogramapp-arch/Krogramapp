import os

from sqlalchemy import create_engine, event
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import scoped_session, sessionmaker

from ..Config import Config
from ..core.logger import logging

LOGS = logging.getLogger(__name__)

BASE = declarative_base()
ENGINE = None
SESSION = None


def _sqlite_url(path):
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    return "sqlite:///" + os.path.abspath(path)


def start() -> scoped_session:
    """ينشئ اتصال SQLite واحدا (WAL + مفاتيح اجنبية) ويجهز الجداول."""
    global ENGINE
    ENGINE = create_engine(
        _sqlite_url(Config.DB_PATH),
        connect_args={"check_same_thread": False, "timeout": 30},
        pool_pre_ping=True,
    )

    @event.listens_for(ENGINE, "connect")
    def _pragmas(dbapi_connection, _):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    BASE.metadata.bind = ENGINE
    BASE.metadata.create_all(ENGINE)
    return scoped_session(sessionmaker(bind=ENGINE, autoflush=False))


def close_db():
    """يغلق الجلسات والاتصالات بأمان عند الايقاف."""
    try:
        if SESSION is not None:
            SESSION.remove()
        if ENGINE is not None:
            ENGINE.dispose()
    except Exception as exc:
        LOGS.error(f"تعذر اغلاق قاعدة البيانات: {type(exc).__name__}")


SESSION = start()
