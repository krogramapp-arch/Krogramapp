"""Inline buttons for search results (assistant bot side).

The userbot stores results in dl_send.STORE and asks the assistant bot for an inline result
"kro:<token>". Only the owner can open or press these buttons.
Enable inline mode for your bot in @BotFather (/setinline) or the buttons cannot be sent;
the commands then fall back to a plain numbered list.

KroTheCommander - Dev @krofullpower | Ch @dlxfullpower
Modified from KroTheCommander (AGPL-3.0). Original authors' notices are kept in LICENSE and NOTICE.md.
"""
import re

from telethon import Button, events

from sbb_b import sbb_b

from ..Config import Config
from ..core.logger import logging
from ..helpers import dl_common as dc
from ..helpers import dl_engine as eng
from ..helpers import dl_send

LOGS = logging.getLogger("KroTheCommander")
tgbot = sbb_b.tgbot


def _is_owner(user_id):
    return bool(user_id) and user_id == Config.OWNER_ID


def _menu(token, data):
    items = data["items"]
    lines = [f"**{data.get('heading', 'Results')}**", ""]
    for i, it in enumerate(items, 1):
        dur = dc.fmt_duration(it.get("duration")) if it.get("duration") else ""
        who = f" - {it['uploader']}" if it.get("uploader") else ""
        lines.append(f"{i}. {it['title'][:70]}{who}" + (f" [{dur}]" if dur else ""))
    rows = []
    n = len(items)
    if "v" in data["formats"]:
        rows.append([Button.inline(f"Video {i + 1}", data=f"kro:{token}:{i}:v") for i in range(n)])
    if "a" in data["formats"]:
        label = "Audio" if "v" in data["formats"] else "Get"
        rows.append([Button.inline(f"{label} {i + 1}", data=f"kro:{token}:{i}:a") for i in range(n)])
    rows.append([Button.inline("Close", data=f"kro:{token}:x:x")])
    return "\n".join(lines), rows


@tgbot.on(events.InlineQuery(pattern=r"^kro:([0-9a-f]{8})$"))
async def media_inline(event):
    if not _is_owner(event.query.user_id):
        return
    data = dl_send.STORE.get(event.pattern_match.group(1))
    if not data:
        return await event.answer([], cache_time=0)
    text, rows = _menu(event.pattern_match.group(1), data)
    result = event.builder.article(title="KroTheCommander", text=text, buttons=rows)
    await event.answer([result], cache_time=0, private=True)


@tgbot.on(events.CallbackQuery(data=re.compile(rb"^kro:([0-9a-f]{8}):(\d|x):([vax])$")))
async def media_callback(event):
    if not _is_owner(event.query.user_id):
        return await event.answer("Only the owner can use this.", alert=True)
    token = event.data_match.group(1).decode()
    idx, fmt = event.data_match.group(2).decode(), event.data_match.group(3).decode()
    data = dl_send.STORE.get(token)
    if not data:
        return await event.answer("This menu expired. Search again.", alert=True)

    async def remove_menu():
        dl_send.STORE.drop(token)
        if data.get("msg"):
            try:
                await sbb_b.delete_messages(data["chat"], data["msg"])
            except Exception as exc:
                LOGS.error(f"could not delete menu: {type(exc).__name__}")

    if idx == "x":
        await event.answer("Closed.")
        return await remove_menu()
    try:
        item = data["items"][int(idx)]
    except (IndexError, ValueError):
        return await event.answer("Invalid choice.", alert=True)
    mode = "audio" if fmt == "a" else "video"
    await event.answer("Downloading...")
    try:
        await event.edit(f"**Downloading {'audio' if mode == 'audio' else 'video'}:** {item['title'][:80]}")
    except Exception:
        pass
    try:
        await dl_send.deliver(sbb_b, data["chat"], item["url"], mode, reply_to=data.get("reply"))
        await remove_menu()
    except (eng.DownloadError, dl_send.Busy) as exc:
        try:
            await event.edit(f"**{exc}**")
        except Exception:
            pass
    except Exception as exc:  # one failed chat/send must never stop the userbot
        LOGS.error(f"media callback failed: {type(exc).__name__}")
        try:
            await event.edit("**The download failed.**")
        except Exception:
            pass
