# config values will be loaded from environment only (no config.py with secrets)
from sample_config import Config  # noqa
