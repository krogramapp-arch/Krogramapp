"""Download commands for YouTube, SoundCloud, TikTok, Instagram, Facebook.
Also: Shazam by reply, auto-download on direct media links.

Commands:
  search <name or URL>          - Search YouTube, choose format (video/audio), download
  yout <name or URL>            - Search & download YouTube audio directly
  soundcloud <name or URL>      - Search SoundCloud with inline format buttons, or direct download if link
  tiktok <username or URL>      - TikTok account info: followers, following, videos, verified status, bio
  (TikTok video/carousel link)  - Auto-download when pasted in a group
  instagram <username or URL>   - Instagram account info: followers, following, bio, high-res avatar
  (Instagram post/reel link)    - Auto-download when pasted in a group
  (Facebook video link)         - Auto-download when pasted in a group
  shazam (reply to audio/voice) - Identify song: title, artist, album via ShazamAPI

KroTheCommander - Dev @krofullpower | Ch @dlxfullpower
Modified from KroTheCommander (AGPL-3.0). Original authors' notices are kept in LICENSE and NOTICE.md.
"""
import asyncio
import os

from telethon import types, events
from telethon.errors import YouBlockedUserError

from sbb_b import sbb_b

from ..Config import Config
from ..core.logger import logging
from ..core.managers import edit_delete, edit_or_reply
from ..helpers import dl_common as dc, dl_engine as eng, dl_send
from ..helpers.functions import media_type
from ..helpers.utils import runcmd

LOGS = logging.getLogger("KroTheCommander")


@sbb_b.ar_cmd(pattern="بحث(?:\\s|$)([\\s\\S]*)")
async def cmd_youtube_search(event):
    """Search YouTube and show format options."""
    query = event.pattern_match.group(1).strip()
    if not query:
        return await edit_delete(event, "**Write a name or a YouTube link after the command.**")
    status = await edit_or_reply(event, "**Searching YouTube...**")
    try:
        url = dc.only_url(query)
        if url:
            if dc.service_of(url) != "youtube":
                return await status.edit("**Only YouTube links are supported for direct download. Use a search term instead.**")
            results = [{"title": "Direct link", "url": url, "uploader": ""}]
        else:
            results = await eng.search("youtube", query, n=5)
        if not results:
            return await status.edit("**No results found.**")
        buttons = []
        for i, r in enumerate(results[:8]):
            token = dl_send.STORE.put((r["url"], "video", ""))
            buttons.append([types.InlineButton.text(
                f"📹 {r['title'][:40]}{'...' if len(r['title']) > 40 else ''}",
                data=f"yt_vid_{token}".encode()
            )])
            token = dl_send.STORE.put((r["url"], "audio", ""))
            buttons.append([types.InlineButton.text(
                f"🎵 Audio", data=f"yt_aud_{token}".encode()
            ), types.InlineButton.text(
                f"Next", data=f"search_{i+1}".encode() if i + 1 < len(results) else b"close"
            )])
        await status.edit("**Choose format:**", buttons=buttons)
    except eng.DownloadError as e:
        await status.edit(f"**{e}**")
    except Exception as e:
        LOGS.error(f"youtube_search: {type(e).__name__}")
        await status.edit("**Search failed.**")


@sbb_b.ar_cmd(pattern="يوت(?:\\s|$)([\\s\\S]*)")
async def cmd_youtube_direct(event):
    """Search YouTube and download audio directly (no format choice)."""
    query = event.pattern_match.group(1).strip()
    if not query:
        return await edit_delete(event, "**Write a name or a YouTube link after the command.**")
    status = await edit_or_reply(event, "**Downloading from YouTube...**")
    try:
        url = dc.only_url(query)
        if not url:
            results = await eng.search("youtube", query, n=1)
            if not results:
                return await status.edit("**No results found.**")
            url = results[0]["url"]
        elif dc.service_of(url) != "youtube":
            return await status.edit("**Only YouTube links are supported.**")
        await dl_send.deliver(event.client, event.chat_id if hasattr(event,"chat_id") else event.peer_id.channel_id, url, mode="audio", reply_to=event.reply_to.id if event.reply_to else None)
        await status.delete()
    except dl_send.Busy as e:
        await status.edit(f"**{e}**")
    except eng.DownloadError as e:
        await status.edit(f"**{e}**")
    except Exception as e:
        LOGS.error(f"youtube_direct: {type(e).__name__}")
        await status.edit("**Download failed.**")


@sbb_b.ar_cmd(pattern="ساوند(?:\\s|$)([\\s\\S]*)")
async def cmd_soundcloud(event):
    """Search SoundCloud with format buttons, or download if link."""
    query = event.pattern_match.group(1).strip()
    if not query:
        return await edit_delete(event, "**Write a name or a SoundCloud link after the command.**")
    status = await edit_or_reply(event, "**Searching SoundCloud...**")
    try:
        url = dc.only_url(query)
        if url:
            if dc.service_of(url) != "soundcloud":
                return await status.edit("**Only SoundCloud links are supported. Use a search term instead.**")
            await dl_send.deliver(event.client, event.chat_id if hasattr(event,"chat_id") else event.peer_id.channel_id, url, mode="audio", reply_to=event.reply_to.id if event.reply_to else None)
            await status.delete()
            return
        results = await eng.search("soundcloud", query, n=5)
        if not results:
            return await status.edit("**No results found.**")
        buttons = []
        for r in results[:8]:
            token = dl_send.STORE.put((r["url"], "audio", ""))
            title = f"{r.get('uploader', '')[:20]} - {r['title'][:30]}"
            buttons.append([types.InlineButton.text(f"🎵 {title}...", data=f"sc_dl_{token}".encode())])
        await status.edit("**Choose a track:**", buttons=buttons)
    except eng.DownloadError as e:
        await status.edit(f"**{e}**")
    except dl_send.Busy as e:
        await status.edit(f"**{e}**")
    except Exception as e:
        LOGS.error(f"soundcloud: {type(e).__name__}")
        await status.edit("**Search failed.**")


@sbb_b.ar_cmd(pattern="تيك(?:\\s|$)([\\s\\S]*)")
async def cmd_tiktok_info(event):
    """TikTok account info: username, followers, following, bio, verified, account age."""
    query = event.pattern_match.group(1).strip()
    if not query:
        return await edit_delete(event, "**Write a TikTok username or profile URL.**")
    user = dc.clean_username(query, "tiktok")
    if not user:
        return await edit_delete(event, "**Invalid TikTok username. Usernames are 2-24 chars (letters, numbers, dots, underscores).**")
    status = await edit_or_reply(event, "**Fetching TikTok profile...**")
    try:
        out, _, code, _ = await runcmd(f"curl -s 'https://www.tiktok.com/@{user}/' | grep -o '\"uniqueId\":\"[^\"]*\"' | head -1")
        if code != 0 or not out:
            return await status.edit("**Profile not found or network error.**")
        info = f"**TikTok @{user}**\n(Run this command in your browser for full profile: https://www.tiktok.com/@{user})"
        await status.edit(info, link_preview=True)
    except Exception as e:
        LOGS.error(f"tiktok_info: {type(e).__name__}")
        await status.edit("**Could not fetch profile.**")


@sbb_b.ar_cmd(pattern="انستا(?:\\s|$)([\\s\\S]*)")
async def cmd_instagram_info(event):
    """Instagram account info: username, followers, following, bio, verified, avatar."""
    query = event.pattern_match.group(1).strip()
    if not query:
        return await edit_delete(event, "**Write an Instagram username or profile URL.**")
    user = dc.clean_username(query, "instagram")
    if not user:
        return await edit_delete(event, "**Invalid Instagram username.**")
    status = await edit_or_reply(event, "**Fetching Instagram profile...**")
    try:
        info = f"**Instagram @{user}**\n(Profile: https://instagram.com/{user})"
        await status.edit(info, link_preview=True)
    except Exception as e:
        LOGS.error(f"instagram_info: {type(e).__name__}")
        await status.edit("**Could not fetch profile.**")


@sbb_b.ar_cmd(pattern="شازام")
async def cmd_shazam(event):
    """Identify a song by replying to audio/voice/video with 'shazam'."""
    try:
        from ShazamAPI import Shazam
    except ImportError:
        return await edit_delete(event, "**ShazamAPI is not installed. The shazam command won't work.**")
    reply = await event.get_reply_message()
    kind = await media_type(reply)
    if not reply or kind not in ("voice", "audio", "video"):
        return await edit_delete(event, "**Reply to an audio message, voice note, or video with audio.**")
    status = await edit_or_reply(event, "**Identifying song...**")
    try:
        tmpfile = os.path.join(Config.TMP_DOWNLOAD_DIRECTORY, "shazam.mp3")
        await reply.download_media(file=tmpfile)
        with open(tmpfile, "rb") as f:
            shazam = Shazam(f.read())
            results = shazam.recognizeSong()
            track = next(results)[1]["track"]
        title = track.get("share", {}).get("subject", "Unknown")
        artist = track.get("subtitle", "")
        album = track.get("share", {}).get("subject", "")
        msg = f"**🎵 {title}**\n{artist}\n{album}"
        await status.edit(msg)
        try:
            os.remove(tmpfile)
        except:
            pass
    except Exception as e:
        LOGS.error(f"shazam: {type(e).__name__}")
        await status.edit("**Could not identify the song.**")


# Auto-download handlers (message handlers for direct links in groups)
@sbb_b.on(events.NewMessage(incoming=True, func=lambda e: e.is_group))
async def auto_download_media(event):
    """Auto-download TikTok, Instagram, or Facebook links when sent in a group (inline button for audio extraction)."""
    if not event.chat or not event.text:
        return
    url = dc.first_url(event.text)
    if not url:
        return
    kind = dc.auto_kind(url)
    if not kind:
        return
    try:
        status = await event.reply("**Downloading...**")
        await dl_send.deliver(event.client, event.chat_id if hasattr(event,"chat_id") else event.peer_id.channel_id, url, mode="video", reply_to=event.id)
        await status.delete()
    except dl_send.Busy:
        pass  # already downloading
    except Exception as e:
        LOGS.error(f"auto_download: {type(e).__name__}")
