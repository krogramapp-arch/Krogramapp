import asyncio
import re

from razan.strings import get_download_url
from sbb_b import sbb_b

from ..Config import Config


@sbb_b.ar_cmd(pattern="بينترست ?(.*)")
async def _(event):
    """تحميل وسائط عبر خدمة طرف ثالث (expertsphp.com). معطل افتراضيا لانه يرسل الرابط الى موقع خارجي
    ويحمل الملف الذي يحدده ذلك الموقع. فعله بالمتغير ALLOW_THIRD_PARTY_DOWNLOADERS=true."""
    if not Config.ALLOW_THIRD_PARTY_DOWNLOADERS:
        return await event.edit("**هذا الامر معطل لاسباب امنية. فعله بالمتغير ALLOW_THIRD_PARTY_DOWNLOADERS=true**")
    text = event.pattern_match.group(1)
    links = re.findall(r"https://\S+", text)
    if not links:
        return await event.edit("**يجب وضع رابط صالح يبدا بـ https بعد الامر**")
    await event.edit("**يتم التحميل**")
    url = await asyncio.get_running_loop().run_in_executor(None, get_download_url, links[0])
    if not url or not str(url).startswith("https://"):
        return await event.edit("**تعذر الحصول على رابط التحميل**")
    await event.client.send_file(event.chat_id, url)
    await event.delete()
