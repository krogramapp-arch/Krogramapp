import asyncio
import os

from telethon.errors import FloodWaitError

from sbb_b import sbb_b

# مجموعات مستثناة من الاذاعة (اختياري) بمتغير البيئة GCAST_BLACKLIST مفصولة بمسافة
GCAST_BLACKLIST = [
    int(x) for x in os.environ.get("GCAST_BLACKLIST", "").split() if x.lstrip("-").isdigit()
]
SEND_DELAY = 1.0  # ثانية بين كل رسالتين لتجنب قيود تيليجرام


async def _send(client, chat, msg):
    """يرسل مع احترام FloodWait. يعيد True عند النجاح."""
    try:
        await client.send_message(chat, msg)
        return True
    except FloodWaitError as e:
        await asyncio.sleep(e.seconds + 1)
        try:
            await client.send_message(chat, msg)
            return True
        except Exception:
            return False
    except Exception:
        return False
    finally:
        await asyncio.sleep(SEND_DELAY)


@sbb_b.ar_cmd(pattern="للكروبات(?: |$)(.*)")
async def gcast(event):
    text = event.pattern_match.group(1)
    if text:
        msg = text
    elif event.is_reply:
        msg = await event.get_reply_message()
    else:
        await edit_or_reply(event, "**يجب الرد على رسالة او كتابة النص مع الامر**")
        return
    roz = await edit_or_reply(event, "يتم الاذاعة في المجموعات انتظر قليلا")
    er = 0
    done = 0
    async for x in event.client.iter_dialogs():
        if x.is_group and x.id not in GCAST_BLACKLIST:
            if await _send(event.client, x.id, msg):
                done += 1
            else:
                er += 1
    await roz.edit(f"**تمت الاذاعة الى** `{done}` **دردشة، فشل الارسال الى** `{er}`")


@sbb_b.ar_cmd(pattern="للخاص(?: |$)(.*)")
async def gucast(event):
    text = event.pattern_match.group(1)
    if text:
        msg = text
    elif event.is_reply:
        msg = await event.get_reply_message()
    else:
        await edit_or_reply(event, "**يجب الرد على رسالة او كتابة النص مع الامر**")
        return
    roz = await edit_or_reply(event, "يتم الاذاعة في الخاص انتظر قليلا")
    er = 0
    done = 0
    async for x in event.client.iter_dialogs():
        if x.is_user and not x.entity.bot and x.id not in GCAST_BLACKLIST:
            if await _send(event.client, x.id, msg):
                done += 1
            else:
                er += 1
    await roz.edit(f"**تمت الاذاعة الى** `{done}` **دردشة، فشل الارسال الى** `{er}`")
