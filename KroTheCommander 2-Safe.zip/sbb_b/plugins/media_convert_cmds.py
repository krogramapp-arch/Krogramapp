"""Format conversion commands (reply to media).

Commands (prefix + command, reply to a sticker / GIF / video / video note / audio / voice / photo):
  تحويل فيديو      -> mp4 video
  تحويل متحركة     -> silent GIF (mp4)
  تحويل صورة       -> image (frame or sticker -> picture)
  تحويل صوت        -> mp3 audio file
  تحويل فويس       -> voice message (opus)
  تحويل ملصق       -> sticker (webp, or webm for moving media)
  تحويل فيديو نوت  -> round video note

Everything runs through ffmpeg with argument lists (no shell). TGS stickers are not supported.

KroTheCommander - Dev @krofullpower | Ch @dlxfullpower
Modified from KroTheCommander (AGPL-3.0). Original authors' notices are kept in LICENSE and NOTICE.md.
"""
import asyncio
import os
import shutil
import tempfile

from telethon import types

from sbb_b import sbb_b

from ..Config import Config
from ..core.logger import logging
from ..core.managers import edit_delete, edit_or_reply
from ..helpers import media_convert as mc

LOGS = logging.getLogger("KroTheCommander")
MAX_MB = int(os.environ.get("MAX_DOWNLOAD_MB", "200"))
_SEM = asyncio.Semaphore(1)  # one ffmpeg job at a time (low RAM/CPU hosts)


def _workdir():
    base = Config.TMP_DOWNLOAD_DIRECTORY
    os.makedirs(base, exist_ok=True)
    return tempfile.mkdtemp(prefix="conv_", dir=base)


async def _convert(event, target):
    reply = await event.get_reply_message()
    kind = mc.classify(reply)
    try:
        mc.check_target(kind, target)
    except mc.ConvertError as e:
        return await edit_delete(event, f"**{e}**", 6)
    size = getattr(getattr(reply, "file", None), "size", 0) or 0
    if size > MAX_MB * 1024 * 1024:
        return await edit_delete(event, f"**The file is larger than {MAX_MB} MB.**", 6)
    status = await edit_or_reply(event, "**Converting...**")
    work = _workdir()
    try:
        async with _SEM:
            src = await reply.download_media(file=os.path.join(work, "input"))
            if not src:
                raise mc.ConvertError("Could not download the media.")
            info = await mc.probe(src)
            await _send(event, reply, work, src, kind, target, info)
        await status.delete()
    except mc.ConvertError as e:
        await status.edit(f"**{e}**")
    except Exception as e:  # never stop the userbot because of one bad file
        LOGS.error(f"conversion failed: {type(e).__name__}")
        await status.edit("**The conversion failed.**")
    finally:
        shutil.rmtree(work, ignore_errors=True)


async def _send(event, reply, work, src, kind, target, info):
    client, chat = event.client, event.chat_id
    out = os.path.join(work, "out")
    dur = int(info["duration"] or 0)
    if target == "video":
        path = await mc.to_video(src, out + ".mp4", kind, info)
        meta = await mc.probe(path)
        await client.send_file(chat, path, reply_to=reply.id, supports_streaming=True, attributes=[
            types.DocumentAttributeVideo(duration=int(meta["duration"]), w=meta["width"], h=meta["height"],
                                         supports_streaming=True)])
    elif target == "gif":
        path = await mc.to_gif(src, out + ".mp4", kind, info)
        meta = await mc.probe(path)
        await client.send_file(chat, path, reply_to=reply.id, attributes=[
            types.DocumentAttributeVideo(duration=int(meta["duration"]), w=meta["width"], h=meta["height"]),
            types.DocumentAttributeAnimated()])
    elif target == "image":
        ext = ".jpg" if kind == "photo" else ".png"
        path = await mc.to_image(src, out + ext, kind, info)
        await client.send_file(chat, path, reply_to=reply.id)
    elif target == "audio":
        path = await mc.to_audio(src, out + ".mp3", kind, info)
        await client.send_file(chat, path, reply_to=reply.id, attributes=[
            types.DocumentAttributeAudio(duration=dur, title="Audio", performer="KroTheCommander")])
    elif target == "voice":
        path = await mc.to_voice(src, out + ".ogg", kind, info)
        await client.send_file(chat, path, reply_to=reply.id, voice_note=True, attributes=[
            types.DocumentAttributeAudio(duration=min(dur, 600), voice=True)])
    elif target == "sticker":
        path = await mc.to_sticker(src, out, kind, info)
        mime = "video/webm" if path.endswith(".webm") else "image/webp"
        attrs = [types.DocumentAttributeSticker(alt="", stickerset=types.InputStickerSetEmpty())]
        if mime == "video/webm":
            meta = await mc.probe(path)
            attrs.append(types.DocumentAttributeVideo(duration=int(meta["duration"]), w=meta["width"], h=meta["height"]))
        await client.send_file(chat, path, reply_to=reply.id, mime_type=mime, attributes=attrs, force_document=True)
    elif target == "video_note":
        path = await mc.to_video_note(src, out + ".mp4", kind, info)
        meta = await mc.probe(path)
        await client.send_file(chat, path, reply_to=reply.id, video_note=True, attributes=[
            types.DocumentAttributeVideo(duration=int(meta["duration"]), w=384, h=384, round_message=True)])


@sbb_b.ar_cmd(pattern="تحويل فيديو نوت$")
async def cmd_video_note(event):
    await _convert(event, "video_note")


@sbb_b.ar_cmd(pattern="تحويل فيديو$")
async def cmd_video(event):
    await _convert(event, "video")


@sbb_b.ar_cmd(pattern="(?:تحويل متحركة|لمتحركة)$")
async def cmd_gif(event):
    await _convert(event, "gif")


@sbb_b.ar_cmd(pattern="(?:تحويل صورة|لصورة)$")
async def cmd_image(event):
    await _convert(event, "image")


@sbb_b.ar_cmd(pattern="تحويل صوت$")
async def cmd_audio(event):
    await _convert(event, "audio")


@sbb_b.ar_cmd(pattern="تحويل فويس$")
async def cmd_voice(event):
    await _convert(event, "voice")


@sbb_b.ar_cmd(pattern="(?:تحويل ملصق|لملصق)$")
async def cmd_sticker(event):
    await _convert(event, "sticker")
