import math
import os
import re
import time

import requests
from validators.url import url

from .. import *
from ..Config import Config
from ..core.logger import logging
from ..core.managers import edit_delete, edit_or_reply
from ..core.session import sbb_b
from ..helpers import *
from ..helpers.utils import _format, _jmthonutils, install_pip, reply_id
from ..sql_helper.globals import gvarstatus

bot = sbb_b
LOGS = logging.getLogger(__name__)
USERID = sbb_b.uid if Config.OWNER_ID == 0 else Config.OWNER_ID
ALIVE_NAME = Config.ALIVE_NAME


thumb_image_path = os.path.join(Config.TMP_DOWNLOAD_DIRECTORY, "thumb_image.jpg")

mention = f"[{Config.ALIVE_NAME}](tg://user?id={USERID})"
hmention = f"<a href = tg://user?id={USERID}>{Config.ALIVE_NAME}</a>"

PM_START = []
PMMESSAGE_CACHE = {}
PMMENU = "pmpermit_menu" not in Config.NO_LOAD

TMP_DOWNLOAD_DIRECTORY = Config.TMP_DOWNLOAD_DIRECTORY

if Config.SPAMWATCH_API:
    token = Config.SPAMWATCH_API
    try:
        import spamwatch as spam_watch

        spamwatch = spam_watch.Client(token)
    except ImportError:
        spamwatch = None
else:
    spamwatch = None


if not os.path.isdir(Config.TMP_DOWNLOAD_DIRECTORY):
    os.makedirs(Config.TMP_DOWNLOAD_DIRECTORY)


if Config.THUMB_IMAGE is not None:
    if check := url(Config.THUMB_IMAGE):
        try:
            with open(thumb_image_path, "wb") as f:
                f.write(requests.get(Config.THUMB_IMAGE).content)
        except Exception as e:
            LOGS.info(str(e))


def set_key(dictionary, key, value):
    if key not in dictionary:
        dictionary[key] = value
    elif isinstance(dictionary[key], list):
        if value in dictionary[key]:
            return
        dictionary[key].append(value)
    else:
        dictionary[key] = [dictionary[key], value]
