"""Search / download commands.

  بحث <name|link>       YouTube search with Video/Audio buttons, or direct video if a link is given
  يوت <name|link>       YouTube audio sent directly (no format menu)
  ساوند <name|link>     SoundCloud search with inline buttons, or direct audio for a link
  تيكتوك <username>     TikTok account report (stats, creation date, avatar)
  انستا|انستقرام <user> Instagram account report with the profile picture
  ستوري انستا <link>    Instagram story from a story link (needs INSTAGRAM_COOKIES_FILE)
  شازام                 Reply to a voice/audio/video to identify the song
  الروابط تشغيل|ايقاف   Toggle automatic downloading of TikTok / Instagram / Facebook links
Links sent alone in a message (TikTok videos/photos, Instagram posts/reels, Facebook videos) are
downloaded automatically. Everything is optional, owner only, and uses yt-dlp or public web pages.

KroTheCommander - Dev @krofullpower | Ch @dlxfullpower
Modified from KroTheCommander (AGPL-3.0). Original authors' notices are kept in LICENSE and NOTICE.md.
"""
import asyncio
import json
import os
import re
import shutil
from datetime import datetime, timezone

import aiohttp
from telethon import events

from sbb_b import sbb_b

from ..Config import Config
from ..core.logger import logging
from ..core.managers import edit_delete, edit_or_reply
from ..helpers import dl_common as dc
from ..helpers import dl_engine as eng
from ..helpers import dl_send
from ..helpers import media_convert as mc
from ..sql_helper.globals import addgvar, gvarstatus

LOGS = logging.getLogger("KroTheCommander")
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/124.0 Safari/537.36")
MAX_PAGE = 3 * 1024 * 1024
MAX_IMG = 8 * 1024 * 1024
_NET_SEM = asyncio.Semaphore(3)


# ------------------------------------------------------------------ helpers
async def _arg(event, group=1):
    text = (event.pattern_match.group(group) or "").strip()
    if not text:
        reply = await event.get_reply_message()
        text = (getattr(reply, "raw_text", "") or "").strip() if reply else ""
    return text


async def _run_download(event, url, mode, offer_audio=False):
    status = await edit_or_reply(event, "**Downloading...**")
    try:
        meta = await dl_send.deliver(event.client, event.chat_id, url, mode, reply_to=event.reply_to_msg_id)
        await status.delete()
        return meta
    except (eng.DownloadError, dl_send.Busy) as e:
        await status.edit(f"**{e}**")
    except Exception as e:
        LOGS.error(f"download failed: {type(e).__name__}")
        await status.edit("**The download failed.**")


async def _send_menu(event, token_data, fallback_text):
    """Send the inline results menu through the assistant bot; fall back to plain text."""
    token = dl_send.STORE.put(token_data)
    try:
        results = await event.client.inline_query(Config.TG_BOT_USERNAME, f"kro:{token}")
        sent = await results[0].click(event.chat_id, reply_to=event.reply_to_msg_id)
        data = dl_send.STORE.get(token)
        if data is not None:
            data["msg"] = sent.id
        return True
    except Exception as e:
        LOGS.error(f"inline menu failed ({type(e).__name__}); enable inline mode in @BotFather")
        dl_send.STORE.drop(token)
        return False


async def _search_flow(event, service, formats, heading):
    text = await _arg(event)
    url = dc.first_url(text)
    if url:
        return url, None
    status = await edit_or_reply(event, "**Searching...**")
    try:
        items = await eng.search(service, text, 5)
    except eng.DownloadError as e:
        await status.edit(f"**{e}**")
        return None, None
    except Exception as e:
        LOGS.error(f"search failed: {type(e).__name__}")
        await status.edit("**The search failed.**")
        return None, None
    data = {"items": items, "formats": formats, "heading": f"{heading}: {eng.clean_query(text, 40)}",
            "chat": event.chat_id, "reply": event.reply_to_msg_id, "msg": None}
    if await _send_menu(event, data, ""):
        await status.delete()
    else:
        lines = [f"**{data['heading']}**", ""]
        for i, it in enumerate(items, 1):
            lines.append(f"{i}. {it['title'][:70]} [{dc.fmt_duration(it.get('duration'))}]\n{it['url']}")
        lines.append("\nInline buttons are unavailable. Send a link with the video/audio command instead.")
        await status.edit("\n".join(lines), link_preview=False)
    return None, items


# ------------------------------------------------------------------ search / audio commands
@sbb_b.ar_cmd(pattern="بحث(?:\\s|$)([\\s\\S]*)")
async def cmd_search(event):
    url, _ = await _search_flow(event, "youtube", ("v", "a"), "YouTube results")
    if url:
        if not dc.service_of(url):
            return await edit_delete(event, "**This link is not supported.**", 6)
        await _run_download(event, url, "video")


@sbb_b.ar_cmd(pattern="يوت(?:\\s|$)([\\s\\S]*)")
async def cmd_yt_audio(event):
    text = await _arg(event)
    url = dc.first_url(text)
    if not url:
        status = await edit_or_reply(event, "**Searching...**")
        try:
            items = await eng.search("youtube", text, 1)
        except eng.DownloadError as e:
            return await status.edit(f"**{e}**")
        except Exception as e:
            LOGS.error(f"search failed: {type(e).__name__}")
            return await status.edit("**The search failed.**")
        url = items[0]["url"]
        await status.delete()
    if not dc.service_of(url):
        return await edit_delete(event, "**This link is not supported.**", 6)
    await _run_download(event, url, "audio")


@sbb_b.ar_cmd(pattern="ساوند(?:\\s|$)([\\s\\S]*)")
async def cmd_soundcloud(event):
    url, _ = await _search_flow(event, "soundcloud", ("a",), "SoundCloud results")
    if url:
        if dc.service_of(url) != "soundcloud":
            return await edit_delete(event, "**Send a SoundCloud link or a name.**", 6)
        await _run_download(event, url, "audio")


# ------------------------------------------------------------------ web helpers
async def _http_get(url, *, headers=None, cookies=None, limit=MAX_PAGE, binary=False):
    """Small bounded GET. Returns (status, final_url, body)."""
    h = {"User-Agent": UA, "Accept-Language": "en-US,en;q=0.8"}
    h.update(headers or {})
    timeout = aiohttp.ClientTimeout(total=20)
    async with _NET_SEM:
        async with aiohttp.ClientSession(headers=h, cookies=cookies, timeout=timeout) as s:
            async with s.get(url, max_redirects=3) as r:
                body = bytearray()
                async for chunk in r.content.iter_chunked(65536):
                    body += chunk
                    if len(body) > limit:
                        raise ValueError("response too large")
                return r.status, str(r.url), (bytes(body) if binary else body.decode("utf-8", "replace"))


def _netscape_cookies(path, domain):
    cookies = {}
    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            for line in f:
                parts = line.rstrip("\n").split("\t")
                if len(parts) >= 7 and domain in parts[0] and not line.startswith("# "):
                    cookies[parts[5]] = parts[6]
    except OSError:
        pass
    return cookies


def _rehydration(html_text):
    m = re.search(r'<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.*?)</script>', html_text, re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(1)).get("__DEFAULT_SCOPE__", {})
    except ValueError:
        return None


async def _send_avatar(event, url, caption):
    """Download an avatar (only from known CDN hosts) and send it with a caption."""
    if url and dc.is_image_host(url):
        work = eng.make_workdir()
        try:
            status, _, body = await _http_get(url, limit=MAX_IMG, binary=True)
            if status == 200 and body:
                path = os.path.join(work, "avatar.jpg")
                with open(path, "wb") as f:
                    f.write(body)
                await event.client.send_file(event.chat_id, path, caption=caption, parse_mode="html",
                                             reply_to=event.reply_to_msg_id)
                return True
        except Exception as e:
            LOGS.error(f"avatar download failed: {type(e).__name__}")
        finally:
            shutil.rmtree(work, ignore_errors=True)
    return False


def _esc(x):
    import html
    return html.escape(str(x if x not in (None, "") else "-"))


# ------------------------------------------------------------------ TikTok account report
async def _tiktok_profile(name):
    status, _, page = await _http_get(f"https://www.tiktok.com/@{name}")
    if status == 404:
        raise eng.DownloadError("This TikTok account was not found.")
    if status != 200:
        raise eng.DownloadError("TikTok blocked the request. Try again later.")
    scope = _rehydration(page)
    detail = (scope or {}).get("webapp.user-detail") or {}
    info = detail.get("userInfo")
    if not info:
        raise eng.DownloadError("This TikTok account was not found or TikTok blocked the request.")
    return info


@sbb_b.ar_cmd(pattern="تيكتوك(?:\\s|$)([\\s\\S]*)")
async def cmd_tiktok_user(event):
    name = dc.clean_username(await _arg(event), "tiktok")
    if not name:
        return await edit_delete(event, "**Write a valid TikTok username after the command.**", 6)
    status = await edit_or_reply(event, "**Fetching account details...**")
    try:
        info = await _tiktok_profile(name)
    except eng.DownloadError as e:
        return await status.edit(f"**{e}**")
    except Exception as e:
        LOGS.error(f"tiktok profile failed: {type(e).__name__}")
        return await status.edit("**Could not fetch this account.**")
    u, st = info.get("user", {}), info.get("stats", {})
    created, note = None, ""
    if u.get("createTime"):
        created = datetime.fromtimestamp(int(u["createTime"]), tz=timezone.utc)
    else:
        created = dc.tiktok_date_from_id(u.get("id"))
        note = " (estimated from the account ID)"
    when = created.strftime("%Y-%m-%d %H:%M UTC") + note if created else "-"
    caption = (
        f"<b>TikTok account</b>\n"
        f"Username: <code>@{_esc(u.get('uniqueId'))}</code>\nName: {_esc(u.get('nickname'))}\n"
        f"ID: <code>{_esc(u.get('id'))}</code>\nCreated: {_esc(when)}\n"
        f"Region: {_esc(u.get('region'))}\nLanguage: {_esc(u.get('language'))}\n"
        f"Verified: {'yes' if u.get('verified') else 'no'}\nPrivate: {'yes' if u.get('privateAccount') else 'no'}\n"
        f"Followers: {dc.human_number(st.get('followerCount'))}\nFollowing: {dc.human_number(st.get('followingCount'))}\n"
        f"Likes: {dc.human_number(st.get('heartCount'))}\nVideos: {dc.human_number(st.get('videoCount'))}\n"
        f"Friends: {dc.human_number(st.get('friendCount'))}\nBio: {_esc(u.get('signature'))}"
    )[:1000]
    if await _send_avatar(event, u.get("avatarLarger"), caption):
        await status.delete()
    else:
        await status.edit(caption, parse_mode="html")


# ------------------------------------------------------------------ Instagram account report
@sbb_b.ar_cmd(pattern="(?:انستا|انستقرام)(?:\\s|$)([\\s\\S]*)")
async def cmd_instagram_user(event):
    name = dc.clean_username(await _arg(event), "instagram")
    if not name:
        return await edit_delete(event, "**Write a valid Instagram username after the command.**", 6)
    status = await edit_or_reply(event, "**Fetching account details...**")
    cookie_file = eng.cookies_path("instagram")
    cookies = _netscape_cookies(cookie_file, "instagram.com") if cookie_file else None
    try:
        code, _, body = await _http_get(
            f"https://www.instagram.com/api/v1/users/web_profile_info/?username={name}",
            headers={"x-ig-app-id": "936619743392459", "Accept": "*/*", "Referer": "https://www.instagram.com/"},
            cookies=cookies)
    except Exception as e:
        LOGS.error(f"instagram profile failed: {type(e).__name__}")
        return await status.edit("**Could not reach Instagram.**")
    if code == 404:
        return await status.edit("**This Instagram account was not found.**")
    try:
        user = json.loads(body)["data"]["user"]
        if not user:
            raise KeyError
    except (ValueError, KeyError, TypeError):
        msg = ("Instagram requires a logged-in session for this request. Set INSTAGRAM_COOKIES_FILE (see README)."
               if code in (301, 302, 401, 403, 429) or not cookies else "Instagram returned no data.")
        return await status.edit(f"**{msg}**")
    caption = (
        f"<b>Instagram account</b>\n"
        f"Username: <code>@{_esc(user.get('username'))}</code>\nName: {_esc(user.get('full_name'))}\n"
        f"ID: <code>{_esc(user.get('id'))}</code>\n"
        f"Verified: {'yes' if user.get('is_verified') else 'no'}\nPrivate: {'yes' if user.get('is_private') else 'no'}\n"
        f"Business: {'yes' if user.get('is_business_account') else 'no'}\nCategory: {_esc(user.get('category_name'))}\n"
        f"Followers: {dc.human_number((user.get('edge_followed_by') or {}).get('count'))}\n"
        f"Following: {dc.human_number((user.get('edge_follow') or {}).get('count'))}\n"
        f"Posts: {dc.human_number((user.get('edge_owner_to_timeline_media') or {}).get('count'))}\n"
        f"Link: {_esc(user.get('external_url'))}\nBio: {_esc(user.get('biography'))}"
    )[:1000]
    if await _send_avatar(event, user.get("profile_pic_url_hd") or user.get("profile_pic_url"), caption):
        await status.delete()
    else:
        await status.edit(caption, parse_mode="html")


@sbb_b.ar_cmd(pattern="ستوري انستا(?:\\s|$)([\\s\\S]*)")
async def cmd_instagram_story(event):
    url = dc.first_url(await _arg(event))
    p = dc.parse_url(url) if url else None
    if not p or dc.service_of(url) != "instagram" or "/stories/" not in p.path:
        return await edit_delete(event, "**Send an Instagram story link (instagram.com/stories/...).**", 6)
    if not eng.cookies_path("instagram"):
        return await edit_delete(
            event, "**Stories need a logged-in session. Set INSTAGRAM_COOKIES_FILE (see README).**", 8)
    await _run_download(event, url, "video")


# ------------------------------------------------------------------ Shazam
@sbb_b.ar_cmd(pattern="شازام$")
async def cmd_shazam(event):
    reply = await event.get_reply_message()
    kind = mc.classify(reply)
    if kind not in ("voice", "audio", "video", "video_note", "gif"):
        return await edit_delete(event, "**Reply to a voice message, audio or video.**", 6)
    size = getattr(getattr(reply, "file", None), "size", 0) or 0
    if size > 30 * 1024 * 1024:
        return await edit_delete(event, "**The file is too large for recognition (30 MB max).**", 6)
    status = await edit_or_reply(event, "**Listening...**")
    work = eng.make_workdir()
    try:
        src = await reply.download_media(file=os.path.join(work, "input"))
        clip = os.path.join(work, "clip.mp3")
        code, _, _ = await mc._run([mc.FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", src, "-vn",
                                    "-t", "25", "-ac", "1", "-ar", "44100", "-c:a", "libmp3lame", clip], timeout=120)
        if code != 0 or not os.path.exists(clip):
            return await status.edit("**This media has no usable audio.**")
        with open(clip, "rb") as f:
            data = f.read()

        def recognise():
            from ShazamAPI import Shazam
            return next(Shazam(data).recognizeSong())[1]

        try:
            result = await asyncio.get_running_loop().run_in_executor(None, recognise)
        except ImportError:
            return await status.edit("**ShazamAPI is not installed on this host.**")
        track = (result or {}).get("track")
        if not track:
            return await status.edit("**No match found.**")
        album = "-"
        for sec in track.get("sections", []):
            for m in sec.get("metadata", []) or []:
                if str(m.get("title", "")).lower() == "album":
                    album = m.get("text", "-")
        link = track.get("url") or ""
        await status.edit(
            f"<b>Song:</b> {_esc(track.get('title'))}\n<b>Artist:</b> {_esc(track.get('subtitle'))}\n"
            f"<b>Album:</b> {_esc(album)}" + (f"\n<a href=\"{_esc(link)}\">Shazam</a>" if link.startswith("https://") else ""),
            parse_mode="html", link_preview=False)
    except StopIteration:
        await status.edit("**No match found.**")
    except Exception as e:
        LOGS.error(f"shazam failed: {type(e).__name__}")
        await status.edit("**Recognition failed.**")
    finally:
        shutil.rmtree(work, ignore_errors=True)


# ------------------------------------------------------------------ automatic links
@sbb_b.ar_cmd(pattern="الروابط(?: (تشغيل|ايقاف))?$")
async def cmd_auto_toggle(event):
    arg = event.pattern_match.group(1)
    if not arg:
        state = "on" if gvarstatus("KRO_AUTO_LINKS") != "0" else "off"
        return await edit_delete(event, f"**Automatic link download is {state}.**", 6)
    addgvar("KRO_AUTO_LINKS", "1" if arg == "تشغيل" else "0")
    await edit_delete(event, f"**Automatic link download is now {'on' if arg == 'تشغيل' else 'off'}.**", 6)


async def _tiktok_photos(url):
    """Fallback for TikTok photo posts (yt-dlp cannot download them): returns (image_urls, music_url)."""
    status, final, page = await _http_get(url)
    if dc.service_of(final) != "tiktok":
        raise eng.DownloadError("Unsupported or unsafe link.")
    scope = _rehydration(page) or {}
    item = (((scope.get("webapp.video-detail") or {}).get("itemInfo") or {}).get("itemStruct")) or {}
    images = [((i.get("imageURL") or {}).get("urlList") or [None])[0] for i in (item.get("imagePost") or {}).get("images", [])]
    images = [i for i in images if i and dc.is_image_host(i)][:10]
    if not images:
        raise eng.DownloadError("Could not read this TikTok post.")
    return images


async def _send_tiktok_photos(event, url):
    images = await _tiktok_photos(url)
    work = eng.make_workdir()
    try:
        paths = []
        for i, img in enumerate(images):
            _, _, body = await _http_get(img, limit=MAX_IMG, binary=True)
            path = os.path.join(work, f"{i}.jpg")
            with open(path, "wb") as f:
                f.write(body)
            paths.append(path)
        await event.client.send_file(event.chat_id, paths, caption=f'<a href="{_esc(url)}">TikTok</a>',
                                     parse_mode="html", reply_to=event.id)
    finally:
        shutil.rmtree(work, ignore_errors=True)


async def _offer_audio(event, url, title):
    """After a TikTok video, send a small inline message with an audio button (assistant bot)."""
    data = {"items": [{"title": title or "TikTok sound", "url": url}], "formats": ("a",), "heading": "TikTok audio",
            "chat": event.chat_id, "reply": event.id, "msg": None}
    await _send_menu(event, data, "")


@sbb_b.on(events.NewMessage(outgoing=True, func=lambda e: bool(e.raw_text) and len(e.raw_text) < 500))
async def auto_links(event):
    if gvarstatus("KRO_AUTO_LINKS") == "0":
        return
    url = dc.only_url(event.raw_text)
    kind = dc.auto_kind(url) if url else None
    if not kind:
        return
    status = await event.reply("**Downloading...**")
    try:
        try:
            meta = await dl_send.deliver(event.client, event.chat_id, url, "video", reply_to=event.id)
        except eng.DownloadError:
            if kind != "tiktok" or "/photo/" not in url:
                raise
            await _send_tiktok_photos(event, url)
            meta = None
        await status.delete()
        if kind == "tiktok" and meta is not None:
            await _offer_audio(event, url, meta.get("title"))
    except (eng.DownloadError, dl_send.Busy) as e:
        await status.edit(f"**{e}**")
    except Exception as e:
        LOGS.error(f"auto link failed: {type(e).__name__}")
        await status.edit("**The download failed.**")
