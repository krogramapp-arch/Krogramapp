"""مقيم رياضي آمن: يسمح فقط بالارقام والعمليات + - * / وقوسين. بديل عن eval."""
import ast
import operator as _op

_BIN = {ast.Add: _op.add, ast.Sub: _op.sub, ast.Mult: _op.mul, ast.Div: _op.truediv}
_UNARY = {ast.UAdd: _op.pos, ast.USub: _op.neg}
MAX_LEN = 80


def safe_calc(expression):
    expression = str(expression).strip()
    if not expression or len(expression) > MAX_LEN:
        raise ValueError("تعبير غير صالح")
    tree = ast.parse(expression, mode="eval")

    def ev(node, depth=0):
        if depth > 20:
            raise ValueError("تعبير معقد")
        if isinstance(node, ast.Expression):
            return ev(node.body, depth + 1)
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _BIN:
            return _BIN[type(node.op)](ev(node.left, depth + 1), ev(node.right, depth + 1))
        if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY:
            return _UNARY[type(node.op)](ev(node.operand, depth + 1))
        raise ValueError("عملية غير مسموحة")

    result = ev(tree)
    if result != result or result in (float("inf"), float("-inf")):
        raise ValueError("نتيجة غير صالحة")
    return result
