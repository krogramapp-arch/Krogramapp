"""اللصق الخارجي معطل افتراضيا.

يرسل هذا الملف نصا الى خدمة طرف ثالث (spaceb.in) فقط اذا فعل المالك المتغير
ALLOW_EXTERNAL_PASTE=true صراحة. تمت ازالة الخدمات التي تعمل بدون HTTPS او مجهولة المشغل
(catbin و nekobin و pasty).
"""
import requests

from ...Config import Config
from ...core.logger import logging

LOGS = logging.getLogger("KroTheCommander")

_DISABLED = {
    "error": "اللصق الخارجي معطل. فعله بالمتغير ALLOW_EXTERNAL_PASTE=true اذا رغبت."
}
_SPACEBIN = "https://spaceb.in/api/v1/documents/"


def _post_spacebin(message, extension="txt"):
    try:
        response = requests.post(
            _SPACEBIN,
            data={"content": message, "extension": extension or "txt"},
            timeout=15,
        )
    except requests.RequestException as exc:
        return {"error": type(exc).__name__}
    if not response.ok:
        return {"error": "تعذر الوصول الى الخدمة"}
    data = response.json()
    if data.get("error") and data.get("status", 0) < 400:
        return {"error": data["error"]}
    doc_id = data["payload"]["id"]
    return {
        "url": f"https://spaceb.in/{doc_id}",
        "raw": f"{_SPACEBIN}{doc_id}/raw",
        "bin": "Spacebin",
    }


def spaste(message, extension="txt"):
    if not Config.ALLOW_EXTERNAL_PASTE:
        return dict(_DISABLED)
    return _post_spacebin(message, extension)


async def s_paste(message, extension="txt"):
    return spaste(message, extension)


async def pastetext(text_to_print, pastetype=None, extension=None):
    return spaste(text_to_print, extension or "txt")
