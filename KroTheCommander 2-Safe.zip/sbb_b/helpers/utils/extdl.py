from ...core.logger import logging

LOGS = logging.getLogger("KroTheCommander")


def install_pip(pipfile):
    """معطل لاسباب امنية: لا يتم تثبيت اي مكتبة اثناء التشغيل.

    ثبت المكتبات المطلوبة يدويا من requirements.txt.
    """
    LOGS.error(f"المكتبة {pipfile} غير مثبتة. ثبتها يدويا وفق requirements.txt (التثبيت التلقائي معطل)")
    return b""
