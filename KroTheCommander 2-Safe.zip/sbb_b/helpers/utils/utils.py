import asyncio
import functools
import shlex
from typing import Tuple

from ...core.logger import logging

LOGS = logging.getLogger(__name__)


RUNCMD_TIMEOUT = 600  # ثانية. تقتل العملية العالقة (مثل ffmpeg) بدل تركها
_PROC_SEM = asyncio.Semaphore(2)  # حد للعمليات الخارجية المتزامنة (حماية RAM/CPU)


async def runcmd(cmd: str) -> Tuple[str, str, int, int]:
    """ينفذ برنامجا خارجيا بدون shell (exec فقط) مع مهلة وحد للتزامن.

    ملاحظة امنية: الامر يقسم بـ shlex. اسماء الملفات التي يتحكم بها المرسل قد تحتوي مسافات او
    علامات اقتباس وتغير حدود المعاملات (حقن معاملات وليس حقن shell). راجع تقرير الامن.
    """
    try:
        args = shlex.split(cmd)
    except ValueError:
        return "", "امر غير صالح", 1, 0
    if not args:
        return "", "امر فارغ", 1, 0
    async with _PROC_SEM:
        process = await asyncio.create_subprocess_exec(
            *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                process.communicate(), timeout=RUNCMD_TIMEOUT
            )
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
            return "", "انتهت مهلة التنفيذ", 124, process.pid
    return (
        stdout.decode("utf-8", "replace").strip(),
        stderr.decode("utf-8", "replace").strip(),
        process.returncode,
        process.pid,
    )


def run_sync(func, *args, **kwargs):
    return asyncio.get_event_loop().run_in_executor(
        None, functools.partial(func, *args, **kwargs)
    )


def run_async(loop, coro):
    return asyncio.run_coroutine_threadsafe(coro, loop).result()


def runasync(func: callable):
    """Run async functions with the right event loop."""
    loop = asyncio.get_event_loop()
    return loop.run_until_complete(func)
