"""Download a link and send the result with the userbot client (Telethon).

KroTheCommander - Dev @krofullpower | Ch @dlxfullpower
Modified from KroTheCommander (AGPL-3.0). Original authors' notices are kept in LICENSE and NOTICE.md.
"""
import html
import os
import shutil

from telethon import types

from . import dl_common as dc
from . import dl_engine as eng

STORE = dc.TokenStore()  # search results / pending buttons, shared with sbb_b/assistant/media_inline.py
_VIDEO_EXT = (".mp4", ".mkv", ".webm", ".mov", ".m4v")
_AUDIO_EXT = (".mp3", ".m4a", ".ogg", ".opus", ".wav", ".flac")
_IMAGE_EXT = (".jpg", ".jpeg", ".png", ".webp")
_active = {"n": 0, "urls": set()}
MAX_JOBS = int(os.environ.get("MAX_CONCURRENT_COMMANDS", "4"))


class Busy(Exception):
    pass


def acquire(key):
    """Bounded job slots + de-duplication of the same chat/url job."""
    if key in _active["urls"]:
        raise Busy("This link is already being processed.")
    if _active["n"] >= MAX_JOBS:
        raise Busy("Too many downloads are running. Try again in a moment.")
    _active["n"] += 1
    _active["urls"].add(key)


def release(key):
    _active["n"] = max(0, _active["n"] - 1)
    _active["urls"].discard(key)


def _caption(meta, url, extra=""):
    title = html.escape(str(meta.get("title") or "")[:200])
    who = html.escape(str(meta.get("uploader") or meta.get("channel") or "")[:80])
    lines = [f"<b>{title}</b>" if title else "", who, extra, f'<a href="{html.escape(url, quote=True)}">Source</a>']
    return "\n".join(x for x in lines if x)[:1000]


async def deliver(client, chat, url, mode="video", reply_to=None, extra_caption=""):
    """Download `url` and send it to `chat`. Raises eng.DownloadError / Busy with user-safe messages."""
    key = (chat, url)
    acquire(key)
    workdir = None
    try:
        files, meta, workdir = await eng.download(url, mode)
        caption = _caption(meta, url, extra_caption)
        media = [f for f in files if f.lower().endswith(_IMAGE_EXT + _VIDEO_EXT + _AUDIO_EXT)] or files
        if mode == "audio":
            path = next((f for f in media if f.lower().endswith(".mp3")), media[0])
            title = str(meta.get("track") or meta.get("title") or "Audio")[:100]
            performer = str(meta.get("artist") or meta.get("uploader") or "")[:100]
            attrs = [types.DocumentAttributeAudio(duration=int(meta.get("duration") or 0), title=title,
                                                  performer=performer)]
            await client.send_file(chat, path, caption=caption, parse_mode="html", reply_to=reply_to,
                                   attributes=attrs, link_preview=False)
        elif len(media) > 1 and all(f.lower().endswith(_IMAGE_EXT + _VIDEO_EXT) for f in media):
            for i in range(0, len(media), 10):  # albums hold up to 10 items
                await client.send_file(chat, media[i:i + 10], caption=caption if i == 0 else None,
                                       parse_mode="html", reply_to=reply_to)
        else:
            path = media[0]
            attrs = None
            if path.lower().endswith(_VIDEO_EXT):
                attrs = [types.DocumentAttributeVideo(duration=int(meta.get("duration") or 0),
                                                      w=int(meta.get("width") or 0), h=int(meta.get("height") or 0),
                                                      supports_streaming=True)]
            await client.send_file(chat, path, caption=caption, parse_mode="html", reply_to=reply_to,
                                   attributes=attrs, supports_streaming=True)
        return meta
    finally:
        release(key)
        if workdir:
            shutil.rmtree(workdir, ignore_errors=True)
