from . import fonts
from . import memeshelper as jmthonmemes
from .aiohttp_helper import AioHttp
from .utils import *

from .chatbot import *
from .functions import *
from .memeifyhelpers import *
from .progress import *
from .qhelper import *
from .tools import *
from .utils import _format, _jmthonutils


async def media_type(msg):
    """Return media kind or None."""
    if not msg: return None
    if msg.sticker: return "sticker"
    if msg.voice: return "voice"
    if msg.audio: return "audio"
    if msg.video: return "video"
    if msg.photo: return "photo"
    return None
