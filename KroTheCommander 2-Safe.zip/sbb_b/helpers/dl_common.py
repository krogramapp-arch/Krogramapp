"""URL validation and small helpers for the downloader commands (stdlib only).

KroTheCommander - Dev @krofullpower | Ch @dlxfullpower
Modified from KroTheCommander (AGPL-3.0). Original authors' notices are kept in LICENSE and NOTICE.md.
"""
import re
import secrets
import time
from datetime import datetime, timezone
from urllib.parse import urlparse

SERVICES = {
    "youtube": ("youtube.com", "youtu.be", "youtube-nocookie.com"),
    "soundcloud": ("soundcloud.com", "snd.sc"),
    "tiktok": ("tiktok.com",),
    "instagram": ("instagram.com", "instagr.am"),
    "facebook": ("facebook.com", "fb.watch", "fb.com"),
}
IMAGE_HOSTS = ("cdninstagram.com", "fbcdn.net", "tiktokcdn.com", "tiktokcdn-us.com", "tiktokv.com")

URL_RE = re.compile(r"https?://[^\s<>\"']+", re.I)
_USER_TT = re.compile(r"^@?[A-Za-z0-9._]{2,24}$")
_USER_IG = re.compile(r"^@?[A-Za-z0-9._]{1,30}$")


def host_matches(host, domains):
    host = (host or "").lower().rstrip(".")
    return any(host == d or host.endswith("." + d) for d in domains)


def parse_url(url):
    """Return a ParseResult for a plain http(s) URL, or None. Rejects credentials and odd ports."""
    try:
        p = urlparse(url.strip())
        if p.scheme not in ("http", "https") or not p.hostname:
            return None
        if p.username or p.password or "@" in p.netloc:
            return None
        if p.port not in (None, 80, 443):
            return None
    except ValueError:
        return None
    return p


def service_of(url):
    p = parse_url(url)
    if not p:
        return None
    for name, domains in SERVICES.items():
        if host_matches(p.hostname, domains):
            return name
    return None


def first_url(text):
    m = URL_RE.search(text or "")
    return m.group(0).rstrip(".,)") if m else None


def only_url(text):
    """The text is exactly one URL (and nothing else)."""
    t = (text or "").strip()
    m = URL_RE.fullmatch(t)
    return t if m else None


def is_image_host(url):
    p = parse_url(url)
    return bool(p and p.scheme == "https" and host_matches(p.hostname, IMAGE_HOSTS))


def auto_kind(url):
    """Classify links that are downloaded automatically when sent alone.
    Returns 'tiktok', 'instagram', 'facebook' or None. Profile pages and stories are NOT auto links."""
    p = parse_url(url)
    if not p:
        return None
    host, path = p.hostname.lower(), p.path.lower()
    if host_matches(host, SERVICES["tiktok"]):
        if host.split(".")[0] in ("vm", "vt") or path.startswith("/t/") or "/video/" in path or "/photo/" in path:
            return "tiktok"
    elif host_matches(host, SERVICES["instagram"]):
        if re.match(r"^/(?:[^/]+/)?(p|reel|reels|tv)/[\w-]+", path):
            return "instagram"
    elif host_matches(host, SERVICES["facebook"]):
        if host_matches(host, ("fb.watch",)) or re.search(r"/(videos?|reel|watch|share/[vr])\b", path) or "video.php" in path:
            return "facebook"
    return None


def clean_username(text, service):
    t = (text or "").strip()
    p = parse_url(t) if t.startswith("http") else None
    if p:
        m = re.match(r"^/@?([A-Za-z0-9._]+)/?$", p.path)
        t = m.group(1) if m else ""
    rx = _USER_TT if service == "tiktok" else _USER_IG
    if not rx.match(t):
        return None
    return t.lstrip("@")


def tiktok_date_from_id(user_id):
    """TikTok ids are snowflake-like: the high 32 bits are a unix timestamp. Returns an aware datetime or None."""
    try:
        ts = int(user_id) >> 32
        if 1_400_000_000 < ts < 4_100_000_000:
            return datetime.fromtimestamp(ts, tz=timezone.utc)
    except (TypeError, ValueError, OverflowError):
        pass
    return None


def human_number(n):
    try:
        n = int(n)
    except (TypeError, ValueError):
        return "-"
    return f"{n:,}"


def human_size(n):
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024


def fmt_duration(sec):
    try:
        sec = int(sec)
    except (TypeError, ValueError):
        return "-"
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


class TokenStore:
    """Small in-memory store (TTL + size cap) that remembers search results behind inline buttons."""

    def __init__(self, ttl=900, cap=20):
        self.ttl, self.cap, self._d = ttl, cap, {}

    def put(self, value):
        now = time.monotonic()
        for k in [k for k, (t, _) in self._d.items() if now - t > self.ttl]:
            self._d.pop(k, None)
        while len(self._d) >= self.cap:
            self._d.pop(min(self._d, key=lambda k: self._d[k][0]))
        token = secrets.token_hex(4)
        self._d[token] = (now, value)
        return token

    def get(self, token):
        item = self._d.get(token)
        if not item or time.monotonic() - item[0] > self.ttl:
            self._d.pop(token, None)
            return None
        return item[1]

    def drop(self, token):
        self._d.pop(token, None)
