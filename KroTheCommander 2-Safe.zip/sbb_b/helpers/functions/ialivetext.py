import time

from ...Config import Config
from .utils import get_readable_time

# UniBorg Telegram UseRBot
# Copyright (C) 2020 @UniBorg
# هذا الملف مشتق من اعمال مفتوحة المصدر. تم الابقاء على اشعار الحقوق الاصلي.


def check_data_base_heal_th():
    is_database_working = False
    output = "لم يتم تهيئة قاعدة البيانات"
    from ...sql_helper import SESSION
    from sqlalchemy import text

    try:
        SESSION.execute(text("SELECT 1"))
    except Exception as e:
        output = f"خطأ: {type(e).__name__}"
        is_database_working = False
    else:
        output = "تعمل بنجاح"
        is_database_working = True
    return is_database_working, output


async def jmthonalive(StartTime):
    _, check_sgnirts = check_data_base_heal_th()
    sudo = "موجود" if Config.SUDO_USERS else "غير موجود"
    uptime = await get_readable_time((time.time() - StartTime))
    return (
        "KroTheCommander\n"
        f"\nقاعدة البيانات : {check_sgnirts}"
        f"\nالمطور الثانوي : {sudo}"
        f"\nمدة التشغيل : {uptime}"
    )
