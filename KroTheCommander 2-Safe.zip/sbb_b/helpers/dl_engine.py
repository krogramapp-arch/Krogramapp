"""yt-dlp wrapper used by the download/search commands. No Telethon imports here.

KroTheCommander - Dev @krofullpower | Ch @dlxfullpower
Modified from KroTheCommander (AGPL-3.0). Original authors' notices are kept in LICENSE and NOTICE.md.

Safety rules: only URLs of the five supported services are accepted (see dl_common.service_of),
file size/duration are capped, playlists are off (except a small cap for Instagram carousels),
temporary files live in a private work dir that the caller removes, and raw extractor errors are
logged by type only and never shown to the user.
"""
import asyncio
import os
import re
import shutil
import tempfile

from . import dl_common as dc

MAX_MB = int(os.environ.get("MAX_DOWNLOAD_MB", "200"))
MAX_SECONDS = int(os.environ.get("MAX_DURATION_SEC", "3600"))
TMP_BASE = os.environ.get("TMP_DOWNLOAD_DIRECTORY", "downloads")
_SEM = asyncio.Semaphore(2)  # at most 2 concurrent downloads
_SKIP_EXT = (".part", ".ytdl", ".json", ".tmp", ".temp", ".vtt", ".srt")


class DownloadError(Exception):
    """Message is safe to show to the user."""


def cookies_path(service):
    path = os.environ.get(f"{service.upper()}_COOKIES_FILE")
    return path if path and os.path.isfile(path) else None


def make_workdir():
    os.makedirs(TMP_BASE, exist_ok=True)
    return tempfile.mkdtemp(prefix="dl_", dir=TMP_BASE)


def clean_query(text, limit=100):
    text = re.sub(r"[\x00-\x1f\x7f]", " ", text or "").strip()
    return text[:limit]


def build_opts(service, workdir, mode):
    o = {
        "outtmpl": os.path.join(workdir, "%(id).60B.%(ext)s"),
        "restrictfilenames": True,
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "socket_timeout": 20,
        "retries": 3,
        "max_filesize": MAX_MB * 1024 * 1024,
        "concurrent_fragment_downloads": 2,
        "writethumbnail": False,
        "writesubtitles": False,
        "overwrites": True,
        "paths": {"home": workdir, "temp": workdir},
    }
    if mode == "audio":
        o["format"] = "bestaudio/best"
        o["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}]
    else:
        o["format"] = ("bv*[ext=mp4][height<=720]+ba[ext=m4a]/b[ext=mp4][height<=720]/"
                       "bv*[height<=720]+ba/b[height<=720]/b")
        o["merge_output_format"] = "mp4"
    if service == "instagram":  # carousels: small cap
        o["noplaylist"] = False
        o["playlist_items"] = "1-10"
    cookie = cookies_path(service)
    if cookie:
        o["cookiefile"] = cookie
    return o


def _friendly(exc_text):
    t = exc_text.lower()
    if any(k in t for k in ("login", "log in", "cookies", "authentication", "sign in")):
        return "This content needs a logged-in session. Set the *_COOKIES_FILE variable for that service (see README)."
    if any(k in t for k in ("private", "not available", "unavailable", "removed", "deleted")):
        return "This content is private, removed or unavailable."
    if any(k in t for k in ("429", "too many requests", "rate")):
        return "The service is rate limiting requests. Try again later."
    if "unsupported url" in t:
        return "This link type is not supported."
    return "Could not download this link (the service may be blocking requests)."


def _import_ytdlp():
    try:
        import yt_dlp
    except ImportError as exc:
        raise DownloadError("yt-dlp is not installed on this host.") from exc
    return yt_dlp


def _download_sync(url, opts):
    yt_dlp = _import_ytdlp()
    opts = dict(opts)
    opts["match_filter"] = yt_dlp.utils.match_filter_func(f"!is_live & duration <=? {MAX_SECONDS}")
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            return ydl.extract_info(url, download=True)
    except Exception as exc:  # yt_dlp raises several error classes
        raise DownloadError(_friendly(str(exc))) from None


def _search_sync(prefix, query, n):
    yt_dlp = _import_ytdlp()
    opts = {"quiet": True, "no_warnings": True, "extract_flat": True, "socket_timeout": 20, "noplaylist": True}
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(f"{prefix}{n}:{query}", download=False)
    except Exception as exc:
        raise DownloadError(_friendly(str(exc))) from None
    return (info or {}).get("entries") or []


async def search(service, query, n=5):
    """Search YouTube (service='youtube') or SoundCloud. Returns [{title, url, duration, uploader}]."""
    query = clean_query(query)
    if not query:
        raise DownloadError("Write a name or a link after the command.")
    prefix = {"youtube": "ytsearch", "soundcloud": "scsearch"}[service]
    entries = await asyncio.get_running_loop().run_in_executor(None, _search_sync, prefix, query, n)
    results = []
    for e in entries:
        if not e:
            continue
        url = e.get("webpage_url") or e.get("url")
        if service == "youtube" and e.get("id") and not (url or "").startswith("http"):
            url = f"https://www.youtube.com/watch?v={e['id']}"
        if not url or dc.service_of(url) != service:
            continue
        results.append({
            "title": (e.get("title") or "Untitled")[:120],
            "url": url,
            "duration": e.get("duration"),
            "uploader": (e.get("uploader") or e.get("channel") or "")[:60],
        })
    if not results:
        raise DownloadError("No results found.")
    return results


async def download(url, mode="video"):
    """Download `url`. Returns (files, meta, workdir). The CALLER must shutil.rmtree(workdir)."""
    service = dc.service_of(url)
    if not service:
        raise DownloadError("Unsupported or unsafe link.")
    workdir = make_workdir()
    try:
        async with _SEM:
            meta = await asyncio.get_running_loop().run_in_executor(
                None, _download_sync, url, build_opts(service, workdir, mode))
        files = sorted(
            os.path.join(workdir, f) for f in os.listdir(workdir)
            if os.path.isfile(os.path.join(workdir, f)) and not f.endswith(_SKIP_EXT)
        )
        if not files:
            raise DownloadError(f"Nothing was downloaded (the file may be larger than {MAX_MB} MB or too long).")
        return files, (meta or {}), workdir
    except BaseException:
        shutil.rmtree(workdir, ignore_errors=True)
        raise
