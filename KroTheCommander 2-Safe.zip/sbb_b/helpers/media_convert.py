"""ffmpeg based media conversion (stdlib only, no shell, argument lists only).

KroTheCommander - Dev @krofullpower | Ch @dlxfullpower
Modified from KroTheCommander (AGPL-3.0). Original authors' notices are kept in LICENSE and NOTICE.md.
"""
import asyncio
import json
import os
import shutil

FFMPEG = shutil.which("ffmpeg") or "ffmpeg"
FFPROBE = shutil.which("ffprobe") or "ffprobe"
TIMEOUT = 300

# kinds produced by classify(): what the replied-to media is
KINDS = (
    "sticker", "sticker_video", "tgs", "gif", "video_note",
    "video", "voice", "audio", "photo",
)
VISUAL = {"sticker", "sticker_video", "gif", "video_note", "video", "photo"}
HAS_MOTION = {"sticker_video", "gif", "video_note", "video"}
HAS_AUDIO = {"video_note", "video", "voice", "audio"}

# which input kinds each target accepts
TARGETS = {
    "video": VISUAL,
    "gif": HAS_MOTION,
    "image": VISUAL,
    "audio": HAS_AUDIO,
    "voice": HAS_AUDIO,
    "sticker": VISUAL,
    "video_note": HAS_MOTION,
}


class ConvertError(Exception):
    """Error with a message that is safe to show to the user."""


def classify(msg):
    """Return the media kind of a Telethon message (duck typed), or None."""
    if msg is None:
        return None
    mime = (getattr(getattr(msg, "file", None), "mime_type", None) or "").lower()
    if getattr(msg, "sticker", None):
        if mime == "application/x-tgsticker":
            return "tgs"
        return "sticker_video" if mime == "video/webm" else "sticker"
    if getattr(msg, "video_note", None):
        return "video_note"
    if getattr(msg, "gif", None):
        return "gif"
    if getattr(msg, "voice", None):
        return "voice"
    if getattr(msg, "audio", None):
        return "audio"
    if getattr(msg, "video", None):
        return "video"
    if getattr(msg, "photo", None):
        return "photo"
    if mime.startswith("image/"):
        return "photo"
    return None


def check_target(kind, target):
    """Raise ConvertError if the conversion is not possible."""
    if kind == "tgs":
        raise ConvertError("Animated TGS stickers are not supported for conversion.")
    if kind is None:
        raise ConvertError("Reply to a sticker, GIF, video, video note, audio, voice or photo.")
    if kind not in TARGETS[target]:
        raise ConvertError(f"A {kind.replace('_', ' ')} cannot be converted to {target.replace('_', ' ')}.")


async def _run(args, timeout=TIMEOUT):
    proc = await asyncio.create_subprocess_exec(
        *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        raise ConvertError("The conversion timed out.")
    return proc.returncode, out, err


async def probe(path):
    """Return dict(duration, width, height, has_audio, has_video)."""
    code, out, _ = await _run(
        [FFPROBE, "-v", "error", "-print_format", "json", "-show_format", "-show_streams", path],
        timeout=60,
    )
    if code != 0:
        raise ConvertError("The file could not be read as media.")
    data = json.loads(out.decode("utf-8", "replace") or "{}")
    info = {"duration": 0.0, "width": 0, "height": 0, "has_audio": False, "has_video": False}
    try:
        info["duration"] = float(data.get("format", {}).get("duration") or 0)
    except ValueError:
        pass
    for s in data.get("streams", []):
        if s.get("codec_type") == "video" and not info["has_video"]:
            info["has_video"] = True
            info["width"] = int(s.get("width") or 0)
            info["height"] = int(s.get("height") or 0)
        elif s.get("codec_type") == "audio":
            info["has_audio"] = True
    return info


def _base(src):
    return [FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", src]


EVEN = "scale=trunc(iw/2)*2:trunc(ih/2)*2"


async def _encode(args, dst):
    code, _, err = await _run(args)
    if code != 0 or not os.path.exists(dst) or os.path.getsize(dst) == 0:
        raise ConvertError("The conversion failed for this file.")
    return dst


async def to_video(src, dst, kind, info):
    if kind in ("photo", "sticker"):
        args = [FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-loop", "1", "-i", src, "-t", "3",
                "-vf", f"{EVEN},format=yuv420p", "-c:v", "libx264", "-r", "25", "-movflags", "+faststart", dst]
    else:
        args = _base(src) + ["-vf", f"{EVEN},format=yuv420p", "-c:v", "libx264", "-preset", "veryfast", "-crf", "26"]
        args += ["-c:a", "aac", "-b:a", "96k"] if info["has_audio"] else ["-an"]
        args += ["-movflags", "+faststart", dst]
    return await _encode(args, dst)


async def to_gif(src, dst, kind, info):
    """Telegram 'GIF' = silent mp4."""
    args = _base(src) + ["-an", "-vf", f"{EVEN},format=yuv420p", "-c:v", "libx264", "-preset", "veryfast",
                         "-crf", "28", "-t", "30", "-movflags", "+faststart", dst]
    return await _encode(args, dst)


async def to_image(src, dst, kind, info):
    """dst must end with .png or .jpg. Takes a frame (about 1s in, or first frame for short clips)."""
    seek = []
    if kind in HAS_MOTION and info["duration"] > 2:
        seek = ["-ss", "1"]
    scale = "scale='min(2560,iw)':'min(2560,ih)':force_original_aspect_ratio=decrease"
    args = [FFMPEG, "-hide_banner", "-loglevel", "error", "-y"] + seek + ["-i", src, "-frames:v", "1",
                                                                          "-vf", scale, dst]
    return await _encode(args, dst)


async def to_audio(src, dst, kind, info):
    if not info["has_audio"]:
        raise ConvertError("This media has no audio track.")
    args = _base(src) + ["-vn", "-c:a", "libmp3lame", "-b:a", "192k", dst]
    return await _encode(args, dst)


async def to_voice(src, dst, kind, info):
    if not info["has_audio"]:
        raise ConvertError("This media has no audio track.")
    args = _base(src) + ["-vn", "-t", "600", "-c:a", "libopus", "-b:a", "48k", "-ar", "48000", "-ac", "1", dst]
    return await _encode(args, dst)


async def to_video_note(src, dst, kind, info):
    vf = "crop='min(iw,ih)':'min(iw,ih)',scale=384:384,format=yuv420p"
    args = _base(src) + ["-t", "60", "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "28"]
    args += ["-c:a", "aac", "-b:a", "64k"] if info["has_audio"] else ["-an"]
    args += ["-movflags", "+faststart", dst]
    return await _encode(args, dst)


STICKER_MAX = 256 * 1024


async def to_sticker(src, dst_base, kind, info):
    """Static sticker -> .webp. Moving media -> .webm (vp9, <=3s, <=256KB). Returns the output path."""
    scale = "scale=512:512:force_original_aspect_ratio=decrease"
    if kind in HAS_MOTION:
        dst = dst_base + ".webm"
        for crf in (34, 40, 46, 52, 58):
            if os.path.exists(dst):
                os.remove(dst)
            args = _base(src) + ["-t", "3", "-an", "-vf", f"{scale},fps=30,format=yuva420p", "-c:v", "libvpx-vp9",
                                 "-b:v", "0", "-crf", str(crf), "-deadline", "good", "-cpu-used", "4", dst]
            await _encode(args, dst)
            if os.path.getsize(dst) <= STICKER_MAX:
                return dst
        raise ConvertError("The sticker could not be made small enough (256 KB limit).")
    dst = dst_base + ".webp"
    args = _base(src) + ["-frames:v", "1", "-vf", scale, "-c:v", "libwebp", "-lossless", "0", "-q:v", "80", dst]
    await _encode(args, dst)
    return dst
