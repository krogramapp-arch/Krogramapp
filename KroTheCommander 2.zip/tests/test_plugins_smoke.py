"""Plugin smoke + flow tests with fakes (no Telegram, no network). Real ffmpeg for the conversion flows."""
import os
import re
import shutil
import subprocess
import sys
import types
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harness as h  # noqa: E402

HAVE_FFMPEG = bool(shutil.which("ffmpeg"))


def _real_pattern(p):
    return "^" + p


class DownloadCmds(unittest.TestCase):
    def setUp(self):
        self.gv = {}
        self.mod, self.patterns = h.load_plugin("media_download_cmds.py", self.gv)
        self.eng = sys.modules["sbb_b.helpers.dl_engine"]
        self.send = sys.modules["sbb_b.helpers.dl_send"]

    def event(self, fn, text, reply=None):
        return h.FakeEvent(h.FakeClient(), self.patterns[fn], text, reply)

    def test_patterns_match_requested_commands(self):
        cases = {
            "cmd_search": ["بحث عمرو دياب", "بحث https://youtu.be/x"],
            "cmd_yt_audio": ["يوت عمرو دياب"],
            "cmd_soundcloud": ["ساوند name", "ساوند https://soundcloud.com/a/b"],
            "cmd_tiktok_user": ["تيكتوك someuser"],
            "cmd_instagram_user": ["انستا someuser", "انستقرام someuser"],
            "cmd_instagram_story": ["ستوري انستا https://www.instagram.com/stories/u/1/"],
            "cmd_shazam": ["شازام"],
        }
        for fn, texts in cases.items():
            for t in texts:
                self.assertTrue(re.match(_real_pattern(self.patterns[fn]), t), (fn, t))
        self.assertFalse(re.match(_real_pattern(self.patterns["cmd_shazam"]), "شازام extra"))

    def test_direct_link_downloads_video(self):
        calls = []

        async def deliver(client, chat, url, mode, reply_to=None, extra_caption=""):
            calls.append((url, mode))
            return {"title": "t"}

        with mock.patch.object(self.send, "deliver", deliver):
            ev = self.event("cmd_search", "بحث https://youtu.be/abc")
            h.run(self.mod.cmd_search(ev))
        self.assertEqual(calls, [("https://youtu.be/abc", "video")])

    def test_yt_audio_name_searches_once_and_downloads_audio(self):
        calls = []

        async def search(service, q, n=5):
            calls.append(("search", service, q, n))
            return [{"title": "x", "url": "https://www.youtube.com/watch?v=1"}]

        async def deliver(client, chat, url, mode, reply_to=None, extra_caption=""):
            calls.append(("deliver", url, mode))

        with mock.patch.object(self.eng, "search", search), mock.patch.object(self.send, "deliver", deliver):
            h.run(self.mod.cmd_yt_audio(self.event("cmd_yt_audio", "يوت some song")))
        self.assertEqual(calls[0], ("search", "youtube", "some song", 1))
        self.assertEqual(calls[1], ("deliver", "https://www.youtube.com/watch?v=1", "audio"))

    def test_unsupported_and_hostile_links_are_refused(self):
        called = []

        async def deliver(*a, **k):
            called.append(1)

        with mock.patch.object(self.send, "deliver", deliver):
            for text in ("بحث http://127.0.0.1/x", "بحث file:///etc/passwd", "بحث https://evil.com/youtube.com"):
                ev = self.event("cmd_search", text)
                # these are not "supported" links -> refused; plain non-URL text would trigger a search instead
                h.run(self.mod.cmd_search(ev)) if dc_first(self, text) else None
        self.assertEqual(called, [])

    def test_search_failure_falls_back_to_text_list(self):
        async def search(service, q, n=5):
            return [{"title": "A", "url": "https://www.youtube.com/watch?v=1", "duration": 65, "uploader": "u"}]

        with mock.patch.object(self.eng, "search", search):
            ev = self.event("cmd_search", "بحث abc")
            h.run(self.mod.cmd_search(ev))
        texts = " ".join(str(t) for _, t in ev.log if t)
        self.assertIn("https://www.youtube.com/watch?v=1", texts)

    def test_auto_links(self):
        calls = []

        async def deliver(client, chat, url, mode, reply_to=None, extra_caption=""):
            calls.append((url, mode))
            return {"title": "tt"}

        def run_text(text):
            ev = h.FakeEvent(h.FakeClient(), "", text)
            h.run(self.mod.auto_links(ev))

        with mock.patch.object(self.send, "deliver", deliver):
            run_text("https://www.tiktok.com/@u/video/123")
            run_text("hello https://www.tiktok.com/@u/video/123")       # not alone -> ignored
            run_text("https://www.instagram.com/someuser/")              # profile -> ignored
            run_text("https://www.youtube.com/watch?v=1")                # youtube is not auto
            run_text("https://www.facebook.com/user/videos/12")
            self.gv["KRO_AUTO_LINKS"] = "0"
            run_text("https://www.tiktok.com/@u/video/999")              # disabled -> ignored
        self.assertEqual([c[0] for c in calls], ["https://www.tiktok.com/@u/video/123",
                                                  "https://www.facebook.com/user/videos/12"])

    def test_story_requires_cookies(self):
        ev = self.event("cmd_instagram_story", "ستوري انستا https://www.instagram.com/stories/u/1/")
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("INSTAGRAM_COOKIES_FILE", None)
            h.run(self.mod.cmd_instagram_story(ev))
        self.assertTrue(any("logged-in" in str(t) for _, t in ev.log))

    def test_tiktok_and_instagram_usernames_are_validated(self):
        for fn, text in (("cmd_tiktok_user", "تيكتوك a;rm -rf /"), ("cmd_instagram_user", "انستا ../../x")):
            ev = self.event(fn, text)
            h.run(getattr(self.mod, fn)(ev))
            self.assertTrue(any("valid" in str(t) for _, t in ev.log), fn)


def dc_first(case, text):
    # True when the text contains a URL (these must be refused, not searched)
    return "://" in text


class EngineWithFakeYtdlp(unittest.TestCase):
    def setUp(self):
        self.mod, _ = h.load_plugin("media_download_cmds.py", {})
        self.eng = sys.modules["sbb_b.helpers.dl_engine"]
        self.seen_opts = []
        seen = self.seen_opts

        class FakeYDL:
            fail = False

            def __init__(self, opts):
                self.opts = opts
                seen.append(opts)

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

            def extract_info(self, url, download=True):
                if FakeYDL.fail:
                    raise RuntimeError("ERROR: Private video. Sign in")
                if not download:
                    return {"entries": [
                        {"title": "A", "id": "1", "url": "https://www.youtube.com/watch?v=1", "duration": 10},
                        {"title": "evil", "url": "http://127.0.0.1/x"},
                        None]}
                home = self.opts["paths"]["home"]
                with open(os.path.join(home, "vid.mp4"), "wb") as f:
                    f.write(b"x" * 10)
                return {"title": "T", "duration": 3}

        self.FakeYDL = FakeYDL
        fake = types.ModuleType("yt_dlp")
        fake.YoutubeDL = FakeYDL
        fake.utils = types.SimpleNamespace(match_filter_func=lambda s: s)
        self.patch = mock.patch.dict(sys.modules, {"yt_dlp": fake})
        self.patch.start()

    def tearDown(self):
        self.patch.stop()

    def test_download_returns_files_and_caller_cleans(self):
        files, meta, work = h.run(self.eng.download("https://www.youtube.com/watch?v=1", "video"))
        self.assertTrue(files[0].endswith("vid.mp4"))
        o = self.seen_opts[-1]
        self.assertTrue(o["noplaylist"])
        self.assertEqual(o["max_filesize"], self.eng.MAX_MB * 1024 * 1024)
        self.assertNotIn("cookiefile", o)
        shutil.rmtree(work)

    def test_audio_mode_extracts_mp3(self):
        _, _, work = h.run(self.eng.download("https://soundcloud.com/a/b", "audio"))
        self.assertEqual(self.seen_opts[-1]["postprocessors"][0]["preferredcodec"], "mp3")
        shutil.rmtree(work)

    def test_instagram_uses_small_carousel_cap(self):
        _, _, work = h.run(self.eng.download("https://www.instagram.com/p/abc/", "video"))
        o = self.seen_opts[-1]
        self.assertFalse(o["noplaylist"])
        self.assertEqual(o["playlist_items"], "1-10")
        shutil.rmtree(work)

    def test_failure_removes_workdir_and_hides_raw_error(self):
        self.FakeYDL.fail = True
        before = set(os.listdir(self.eng.TMP_BASE)) if os.path.isdir(self.eng.TMP_BASE) else set()
        with self.assertRaises(self.eng.DownloadError) as cm:
            h.run(self.eng.download("https://www.youtube.com/watch?v=1", "video"))
        self.FakeYDL.fail = False
        self.assertNotIn("RuntimeError", str(cm.exception))
        after = set(os.listdir(self.eng.TMP_BASE))
        self.assertEqual(before, after)

    def test_unsafe_url_is_refused_before_any_network_use(self):
        n = len(self.seen_opts)
        for url in ("file:///etc/passwd", "http://localhost/x", "https://evil.com/?youtube.com"):
            with self.assertRaises(self.eng.DownloadError):
                h.run(self.eng.download(url, "video"))
        self.assertEqual(len(self.seen_opts), n)

    def test_cookies_only_when_file_exists(self):
        path = os.path.join(h.TMP, "cookies.txt")
        open(path, "w").write("# Netscape\n")
        with mock.patch.dict(os.environ, {"INSTAGRAM_COOKIES_FILE": path}):
            _, _, work = h.run(self.eng.download("https://www.instagram.com/p/abc/", "video"))
        self.assertEqual(self.seen_opts[-1]["cookiefile"], path)
        shutil.rmtree(work)

    def test_search_filters_foreign_hosts(self):
        res = h.run(self.eng.search("youtube", "x", 5))
        self.assertEqual([r["url"] for r in res], ["https://www.youtube.com/watch?v=1"])
        with self.assertRaises(self.eng.DownloadError):
            h.run(self.eng.search("youtube", "   ", 5))

    def test_deliver_cleans_up_and_limits_jobs(self):
        send = sys.modules["sbb_b.helpers.dl_send"]
        client = h.FakeClient()
        h.run(send.deliver(client, 5, "https://www.youtube.com/watch?v=1", "video"))
        self.assertEqual(len(client.sent), 1)
        self.assertEqual(send._active["n"], 0)
        self.assertEqual(os.listdir(self.eng.TMP_BASE), [])
        send.acquire((9, "u"))
        with self.assertRaises(send.Busy):
            send.acquire((9, "u"))
        send.release((9, "u"))


class FakeMedia:
    """Duck-typed Telethon message whose download copies a real file."""

    def __init__(self, path, **flags):
        self.src, self.id = path, 3
        base = dict(sticker=None, video_note=None, gif=None, voice=None, audio=None, video=None, photo=None)
        base.update(flags)
        self.__dict__.update(base)
        self.file = types.SimpleNamespace(mime_type=flags.pop("mime", None), size=os.path.getsize(path))

    async def download_media(self, file=None):
        shutil.copy(self.src, file)
        return file


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg not installed")
class ConversionCommandsEndToEnd(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mod, cls.patterns = h.load_plugin("media_convert_cmds.py")
        d = h.TMP
        cls.video = os.path.join(d, "in.mkv")
        cls.photo = os.path.join(d, "in.png")
        subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "testsrc=size=320x240:rate=25:duration=4",
                        "-f", "lavfi", "-i", "sine=duration=4", "-shortest", "-c:v", "ffv1", cls.video], check=True)
        subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "testsrc=size=300x200",
                        "-frames:v", "1", cls.photo], check=True)

    def run_cmd(self, fn, text, media):
        client = h.FakeClient()
        ev = h.FakeEvent(client, self.patterns[fn], text, reply=media)
        h.run(getattr(self.mod, fn)(ev))
        return client, ev

    def test_all_commands_on_a_video(self):
        for fn, text in (("cmd_video", "تحويل فيديو"), ("cmd_gif", "تحويل متحركة"), ("cmd_image", "تحويل صورة"),
                         ("cmd_audio", "تحويل صوت"), ("cmd_voice", "تحويل فويس"), ("cmd_sticker", "تحويل ملصق"),
                         ("cmd_video_note", "تحويل فيديو نوت")):
            client, ev = self.run_cmd(fn, text, FakeMedia(self.video, video=True))
            self.assertEqual(len(client.sent), 1, (fn, ev.log))
            self.assertIn(("delete", None), ev.log, fn)

    def test_photo_to_sticker_video_image_and_refusals(self):
        c, ev = self.run_cmd("cmd_sticker", "تحويل ملصق", FakeMedia(self.photo, photo=True))
        self.assertTrue(c.sent[0][1].endswith(".webp"))
        c, ev = self.run_cmd("cmd_video", "تحويل فيديو", FakeMedia(self.photo, photo=True))
        self.assertEqual(len(c.sent), 1)
        c, ev = self.run_cmd("cmd_audio", "تحويل صوت", FakeMedia(self.photo, photo=True))
        self.assertEqual(c.sent, [])
        self.assertTrue(any("cannot be converted" in str(t) for _, t in ev.log))

    def test_tgs_not_supported_and_missing_reply(self):
        m = FakeMedia(self.photo, sticker=True)
        m.file.mime_type = "application/x-tgsticker"
        c, ev = self.run_cmd("cmd_video", "تحويل فيديو", m)
        self.assertTrue(any("TGS" in str(t) for _, t in ev.log))
        c, ev = self.run_cmd("cmd_video", "تحويل فيديو", None)
        self.assertEqual(c.sent, [])

    def test_workdirs_are_removed(self):
        base = os.environ["TMP_DOWNLOAD_DIRECTORY"]
        self.run_cmd("cmd_audio", "تحويل صوت", FakeMedia(self.video, video=True))
        leftovers = [x for x in os.listdir(base) if x.startswith("conv_")] if os.path.isdir(base) else []
        self.assertEqual(leftovers, [])

    def test_too_large_file_is_refused(self):
        m = FakeMedia(self.video, video=True)
        m.file.size = 10 ** 10
        c, ev = self.run_cmd("cmd_video", "تحويل فيديو", m)
        self.assertEqual(c.sent, [])
        self.assertTrue(any("larger" in str(t) for _, t in ev.log))


if __name__ == "__main__":
    unittest.main()
