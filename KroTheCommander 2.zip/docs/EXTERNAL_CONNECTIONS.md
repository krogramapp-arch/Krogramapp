# الاتصالات الخارجية والاعتماديات المتبقية

كلها تتم عند استدعاء الامر المعني فقط (لا اتصال خلفي دوري سوى تيليجرام). لا اتصال يرسل الجلسة او API_HASH.

| الجهة | الملف/الامر | الغرض | البيانات المرسلة | الحالة |
|---|---|---|---|---|
| Telegram (MTProto) | كل السورس | الوظيفة الاساسية | الجلسة تستخدم محليا للمصادقة مع خوادم تيليجرام الرسمية | ضروري |
| youtube / yt-dlp / youtube-search-python | يوتيوب، utube.py، inlinebot | بحث وتنزيل | نص البحث / الرابط | اختياري |
| openweathermap.org | الطقس | الطقس | اسم المدينة (+ مفتاح API الخاص بك اذا وضع) | اختياري |
| api.pray.zone | الصلاة | اوقات الصلاة | المدينة | اختياري |
| giphy.com | المتحركات | بحث GIF | نص البحث (+ مفتاح) | اختياري |
| animechan.vercel.app | الفحص | اقتباس عشوائي | لا شيء | اختياري |
| anilist / kitsu / myanimelist / jikan | jikan.py | معلومات انمي | نص البحث | اختياري |
| justwatch / imdb | الافلام، functions.py | معلومات افلام | نص البحث | اختياري |
| nekobot.xyz | nekos.py | توليد صور | نص (واحيانا رابط صورة حساب) | اختياري |
| combot.org | الملصقات | بحث حزم ملصقات | نص البحث | اختياري |
| goodreads.com | findquote.py | اقتباسات | نص البحث | اختياري |
| google.com (صور) | google_image_download.py | بحث صور | نص البحث | اختياري |
| mohfw.gov.in | functions.py | احصاءات كورونا الهند | الولاية | اختياري |
| imgur / ytimg | inlinebot، utube | صور مصغرة ثابتة | لا شيء | اختياري |
| github raw / play.google.com | تطبيق | معلومات تطبيقات | الاسم | اختياري |
| spaceb.in | helpers/utils/paste.py | لصق نصوص | النص كاملا | معطل افتراضيا (ALLOW_EXTERNAL_PASTE) |
| expertsphp.com | بينترست (razan/strings/helper.py) | تحميل وسائط | الرابط | معطل افتراضيا (ALLOW_THIRD_PARTY_DOWNLOADERS) |

لم افحص سلوك كل خدمة. استخدام اي اضافة تتصل بخدمة يعني الوثوق بها. يمكن تعطيل اي اضافة بالمتغير NO_LOAD.

## الاعتماديات (requirements.txt)
مستخرجة من تحليل AST للاستيرادات الفعلية. لم تفحص بقواعد الثغرات (لا شبكة). القاعدة: telethon، sqlalchemy (1.4)، sqlalchemy-json، aiohttp، requests، beautifulsoup4، lxml، Pillow، emoji==1.7.0، numpy، وغيرها. الحزم الاختيارية الخاصة بميزات (gtts، googletrans، yt-dlp، PyMuPDF، selenium...) تتعطل اوامرها فقط عند غيابها.
مكتبات محتاجة لتجربة التوافق: sqlalchemy 1.4 مع الكود المكتوب لـ 1.3.23، وgoogletrans و telegraph (واجهات متغيرة).
