"""KroTheCommander - نقطة التشغيل.

نسخة معدلة من KroTheCommander - Dev @krofullpower | Ch @dlxfullpower
"""
import asyncio
import contextlib
import os
import signal
import sys

from .Config import Config

# قفل يمنع تشغيل اكثر من نسخة على نفس البيانات (يتم قبل اي اتصال بتيليجرام)
_LOCK_PATH = os.path.join(os.path.dirname(os.path.abspath(Config.DB_PATH)), "kro.lock")
os.makedirs(os.path.dirname(_LOCK_PATH), exist_ok=True)
_lock_file = open(_LOCK_PATH, "w")
try:
    import fcntl

    fcntl.flock(_lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
except ImportError:  # ويندوز: لا يوجد fcntl
    pass
except OSError:
    print("نسخة اخرى من KroTheCommander تعمل بالفعل على نفس البيانات. تم الايقاف.")
    sys.exit(1)

import sbb_b  # noqa: E402
from sbb_b import BOTLOG_CHATID, PM_LOGGER_GROUP_ID  # noqa: E402

from .core.logger import logging  # noqa: E402
from .core.session import sbb_b as client  # noqa: E402
from .sql_helper import close_db  # noqa: E402
from .utils import (  # noqa: E402
    add_bot_to_logger_group,
    load_plugins,
    setup_bot,
    startupmessage,
    verifyLoggerGroup,
)

LOGS = logging.getLogger("KroTheCommander")
cmdhr = Config.COMMAND_HAND_LER
_shutting_down = False


async def shutdown():
    """ايقاف امن: اغلاق اتصالات تيليجرام ثم قاعدة البيانات."""
    global _shutting_down
    if _shutting_down:
        return
    _shutting_down = True
    LOGS.info("جار الايقاف الامن")
    if _cleanup_task is not None:
        _cleanup_task.cancel()
    for c in (client, getattr(client, "tgbot", None)):
        if c is None:
            continue
        with contextlib.suppress(Exception):
            await c.disconnect()


TEMP_DIR = Config.TMP_DOWNLOAD_DIRECTORY  # لا يشمل ./temp لانه يحوي خطوط مطلوبة
TEMP_MAX_AGE = 3600  # ثانية
_cleanup_task = None


def _clean_temp_once():
    import time

    now = time.time()
    if not os.path.isdir(TEMP_DIR):
        return
    for name in os.listdir(TEMP_DIR):
        path = os.path.join(TEMP_DIR, name)
        try:
            if os.path.isfile(path) and not name.endswith((".ttf", ".otf")) and now - os.path.getmtime(path) > TEMP_MAX_AGE:
                os.remove(path)
        except OSError:
            pass


async def _cleanup_loop():
    """تنظيف دوري محدود للملفات المؤقتة القديمة. مهمة واحدة فقط تلغى عند الايقاف."""
    while True:
        await asyncio.sleep(1800)
        await asyncio.get_running_loop().run_in_executor(None, _clean_temp_once)


def _install_signal_handlers(loop):
    for sig in (signal.SIGTERM, signal.SIGINT):
        with contextlib.suppress(NotImplementedError, RuntimeError):
            loop.add_signal_handler(sig, lambda: loop.create_task(shutdown()))


try:
    LOGS.info("يتم بدء البوت المساعد")
    client.loop.run_until_complete(setup_bot())
    LOGS.info("اكتملت عملية البوت المساعد")
except Exception as e:
    LOGS.error(f"فشل التهيئة: {type(e).__name__}")
    close_db()
    sys.exit(1)

_install_signal_handlers(client.loop)


async def startup_process():
    await verifyLoggerGroup()
    await load_plugins("plugins")
    await load_plugins("assistant")
    print("============================================================")
    print("تم انتهاء عملية التنصيب بنجاح")
    print(f"لمعرفة اوامر السورس ارسل {cmdhr}الاوامر")
    print("KroTheCommander - Dev @krofullpower | Ch @dlxfullpower
    print("============================================================")
    if sbb_b.BOTLOG:
        await add_bot_to_logger_group(BOTLOG_CHATID)
    if PM_LOGGER_GROUP_ID != -100:
        await add_bot_to_logger_group(PM_LOGGER_GROUP_ID)
    await startupmessage()
    global _cleanup_task
    _cleanup_task = asyncio.get_running_loop().create_task(_cleanup_loop())


try:
    client.loop.run_until_complete(startup_process())
    if len(sys.argv) in {1, 3, 4}:
        with contextlib.suppress(ConnectionError, asyncio.CancelledError):
            client.run_until_disconnected()
    else:
        client.loop.run_until_complete(shutdown())
finally:
    close_db()
    with contextlib.suppress(Exception):
        _lock_file.close()
