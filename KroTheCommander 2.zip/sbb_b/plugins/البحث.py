import contextlib
import io
import os

from ShazamAPI import Shazam
from telethon import types
from telethon.errors.rpcerrorlist import YouBlockedUserError
from telethon.tl.functions.contacts import UnblockRequest as unblock
from telethon.tl.functions.messages import ImportChatInviteRequest as Get
from validators.url import url

from ..core.logger import logging
from ..core.managers import edit_delete, edit_or_reply
from ..helpers.functions import delete_conv, yt_search
from ..helpers.tools import media_type
from ..helpers.utils import reply_id
from . import sbb_b, song_download

LOGS = logging.getLogger(__name__)

# =========================================================== #
#                           المتغيرات                           #
# =========================================================== #
SONG_SEARCH_STRING = "<code>انتظر يتم العثور على المطلوب</code>"
SONG_NOT_FOUND = "<code>عذرا لم يتم العثور على المطلوب</code>"
SONG_SENDING_STRING = "<code>تم العثور على المطلوب انتظر قليلا</code>"
# =========================================================== #
#                                                             #
# =========================================================== #


@sbb_b.ar_cmd(pattern="فيديو(?:\s|$)([\s\S]*)")
async def vsong(event):
    reply_to_id = await reply_id(event)
    reply = await event.get_reply_message()
    if event.pattern_match.group(1):
        query = event.pattern_match.group(1)
    elif reply and reply.message:
        query = reply.message
    else:
        return await edit_or_reply(
            event,
            "**يجب عليك اضافة اسم المقطع الصوتي التي تريد تنزيله للامـر ، `.فيديو` + العنوان**",
        )
    razanevent = await edit_or_reply(event, "**⌔∮ جـارِ البحث يرجى الانتظار .  .  .**")
    video_link = await yt_search(str(query))
    if not url(video_link):
        return await razanevent.edit(f"**عـذراً لـم استطـع ايجـاد** {query}")
    vsong_file, razanthumb, title = await song_download(
        video_link, razanevent, video=True
    )
    await event.client.send_file(
        event.chat_id,
        vsong_file,
        caption=f"**العنوان:** `{title}`",
        thumb=razanthumb,
        supports_streaming=True,
        reply_to=reply_to_id,
    )
    await razanevent.delete()
    for files in (razanthumb, vsong_file):
        if files and os.path.exists(files):
            os.remove(files)

