import asyncio
import glob
import os
import sys
from datetime import timedelta
from pathlib import Path

from telethon import Button, functions, types, utils
from telethon.errors import (
    BotMethodInvalidError,
    ChannelPrivateError,
    ChannelsTooMuchError,
)

from sbb_b import BOTLOG, BOTLOG_CHATID, PM_LOGGER_GROUP_ID

from ..Config import Config
from ..core.logger import logging
from ..core.session import sbb_b
from ..sql_helper.global_collection import (
    del_keyword_collectionlist,
    get_item_collectionlist,
)
from ..sql_helper.globals import addgvar, gvarstatus
from .pluginmanager import load_module

LOGS = logging.getLogger("KroTheCommander")
cmdhr = Config.COMMAND_HAND_LER
VPS_NOLOAD = []


async def setup_bot():
    """
    لاعداد السورس
    """
    try:
        await sbb_b.connect()
        config = await sbb_b(functions.help.GetConfigRequest())
        for option in config.dc_options:
            if option.ip_address == sbb_b.session.server_address:
                if sbb_b.session.dc_id != option.id:
                    LOGS.warning(
                        f"اصلاح الداتا {sbb_b.session.dc_id}" f" الى {option.id}"
                    )
                sbb_b.session.set_dc(option.id, option.ip_address, option.port)
                break
        bot_details = await sbb_b.tgbot.get_me()
        Config.TG_BOT_USERNAME = f"@{bot_details.username}"
        # await sbb_b.start(bot_token=Config.TG_BOT_USERNAME)
        sbb_b.me = await sbb_b.get_me()
        sbb_b.uid = sbb_b.tgbot.uid = utils.get_peer_id(sbb_b.me)
        if Config.OWNER_ID == 0:
            Config.OWNER_ID = utils.get_peer_id(sbb_b.me)
    except Exception as e:
        LOGS.error(f"فشل الاتصال بالجلسة: {type(e).__name__}")
        sys.exit()


async def startupmessage():
    """
    رسالة التشغيل
    """
    try:
        if BOTLOG:
            await sbb_b.tgbot.send_message(
                BOTLOG_CHATID,
                f"**تم تشغيل KroTheCommander بنجاح**\nالاصدار: `{sbb_b.version}`\nلعرض الاوامر ارسل `{cmdhr}الاوامر`",
            )
    except Exception as e:
        LOGS.error(f"تعذر ارسال رسالة التشغيل: {type(e).__name__}")
        return None
    try:
        msg_details = list(get_item_collectionlist("restart_update"))
        if msg_details:
            msg_details = msg_details[0]
    except Exception as e:
        LOGS.error(e)
        return None
    try:
        if msg_details:
            message = await sbb_b.get_messages(msg_details[0], ids=msg_details[1])
            text = message.text + "\n\n**الان السورس شغال طبيعي.**"
            await sbb_b.edit_message(msg_details[0], msg_details[1], text)
            if gvarstatus("restartupdate") is not None:
                await sbb_b.send_message(
                    msg_details[0],
                    f"{cmdhr}فحص",
                    reply_to=msg_details[1],
                    schedule=timedelta(seconds=10),
                )
            del_keyword_collectionlist("restart_update")
    except Exception as e:
        LOGS.error(e)
        return None


async def add_bot_to_logger_group(chat_id):
    """
    اضافة البوت للكروبات
    """
    bot_details = await sbb_b.tgbot.get_me()
    try:
        await sbb_b(
            functions.messages.AddChatUserRequest(
                chat_id=chat_id,
                user_id=bot_details.username,
                fwd_limit=1000000,
            )
        )
    except BaseException:
        try:
            await sbb_b(
                functions.channels.InviteToChannelRequest(
                    channel=chat_id,
                    users=[bot_details.username],
                )
            )
        except Exception as e:
            LOGS.error(str(e))


async def load_plugins(folder, extfolder=None):
    """
    تحميل ملفات السورس
    """
    if extfolder:
        path = f"{extfolder}/*.py"
        plugin_path = extfolder
    else:
        path = f"sbb_b/{folder}/*.py"
        plugin_path = f"sbb_b/{folder}"
    files = glob.glob(path)
    files.sort()
    success = 0
    failure = []
    for name in files:
        path1 = Path(name)
        shortname = path1.stem
        pluginname = shortname.replace(".py", "")
        if pluginname in Config.NO_LOAD or pluginname in VPS_NOLOAD:
            LOGS.info(f"تم تخطي الملف {shortname} حسب اعدادات NO_LOAD")
            continue
        try:
            load_module(pluginname, plugin_path=plugin_path)
            success += 1
        except ModuleNotFoundError as e:
            # لا يتم تثبيت اي مكتبة تلقائيا. ثبتها يدويا من requirements.txt
            failure.append(shortname)
            LOGS.error(f"لم يتم تحميل {shortname}: المكتبة {e.name} غير مثبتة")
        except Exception as e:
            failure.append(shortname)
            LOGS.error(f"لم يتم تحميل {shortname}: {type(e).__name__}: {e}")
    if extfolder:
        if not failure:
            failure.append("None")
        await sbb_b.tgbot.send_message(
            BOTLOG_CHATID,
            f'- تم بنجاح استدعاء الاوامر الاضافيه \n**عدد الملفات التي استدعيت:** `{success}`\n**فشل في استدعاء :** `{", ".join(failure)}`',
        )


async def verifyLoggerGroup():
    """
    التاكد من كروب التخزين
    """
    if BOTLOG:
        try:
            entity = await sbb_b.get_entity(BOTLOG_CHATID)
            if not isinstance(entity, types.User) and not entity.creator:
                if entity.default_banned_rights.send_messages:
                    LOGS.info(
                        "لا توجد صلاحيات كافية لارسال الرسائل في كروب الحفظ او التخزين"
                    )
                if entity.default_banned_rights.invite_users:
                    LOGS.info(
                        "لا توجد صلاحيات كافية لاضافة الاعضاء في كروب الحفظ او التخزين"
                    )
        except ValueError:
            LOGS.error("لم يتم التعرف على فار كروب الحفظ")
        except TypeError:
            LOGS.error("يبدو انك وضعت فار كروب الحفظ بشكل غير صحيح")
        except Exception as e:
            LOGS.error("هنالك خطا ما للتعرف على فار كروب الحفظ\n" + str(e))
    else:
        LOGS.info("لم يتم تحديد مجموعة السجل (PRIVATE_GROUP_BOT_API_ID). سيعمل السورس بدونها ولن يتم انشاء مجموعات تلقائيا")
    if PM_LOGGER_GROUP_ID != -100:
        try:
            entity = await sbb_b.get_entity(PM_LOGGER_GROUP_ID)
            if not isinstance(entity, types.User) and not entity.creator:
                if entity.default_banned_rights.send_messages:
                    LOGS.info("لا توجد صلاحيات كافية لارسال الرسائل في كروب التخزين")
                if entity.default_banned_rights.invite_users:
                    LOGS.info("لا توجد صلاحيات كافية لاضافة الاعضاء في كروب التخزين")
        except ValueError:
            LOGS.error(
                "لم يتم العثور على ايدي كروب التخزين تاكد من انه مكتوب بشكل صحيح "
            )
        except TypeError:
            LOGS.error("صيغه ايدي كروب التخزين غير صالحة.تاكد من انه مكتوب بشكل صحيح ")
        except Exception as e:
            LOGS.error("حدث خطأ اثناء التعرف على كروب التخزين\n" + str(e))
