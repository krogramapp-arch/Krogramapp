import SwiftUI

@main
@MainActor
struct KroChatApp: App {
    @StateObject private var themes: ThemeStore
    @StateObject private var privacy: PrivacyMode
    @StateObject private var chats: ChatsViewModel
    @StateObject private var session: SessionStore
    @Environment(\.scenePhase) private var scenePhase

    init() {
        let privacyMode = PrivacyMode.shared
        let chatsModel = ChatsViewModel(repository: MockChatRepository(), privacy: privacyMode)
        _themes = StateObject(wrappedValue: ThemeStore())
        _privacy = StateObject(wrappedValue: privacyMode)
        _chats = StateObject(wrappedValue: chatsModel)
        _session = StateObject(wrappedValue: SessionStore(chats: chatsModel, privacy: privacyMode))
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(themes)
                .environmentObject(privacy)
                .environmentObject(chats)
                .environmentObject(session)
                .tint(themes.current.accent)
                .preferredColorScheme(themes.appearance.scheme)
                .task { await session.bootstrap() }
                .onChange(of: scenePhase) { _, phase in
                    chats.setForeground(phase == .active)
                }
        }
    }
}

struct RootView: View {
    @EnvironmentObject private var session: SessionStore

    var body: some View {
        Group {
            switch session.phase {
            case .live, .demo:
                RootTabView()
                    .transition(KroBlurTransition())
            default:
                LoginView()
                    .transition(KroBlurTransition())
            }
        }
        .animation(.smooth, value: isInApp)
    }

    private var isInApp: Bool {
        session.phase == .live || session.phase == .demo
    }
}
