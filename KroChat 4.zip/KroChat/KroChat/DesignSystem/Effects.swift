import SwiftUI

enum EffectsLevel: String, CaseIterable, Identifiable, Codable {
    case off, balanced, full
    var id: String { rawValue }
    var titleKey: String { "effects.\(rawValue)" }
}

// MARK: - Neon glow

private struct NeonGlowModifier: ViewModifier {
    @EnvironmentObject private var themes: ThemeStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let color: Color
    let radius: CGFloat

    func body(content: Content) -> some View {
        let level = themes.effectiveEffects(reduceMotion: reduceMotion)
        switch level {
        case .off:
            content
        case .balanced:
            content.shadow(color: color.opacity(0.5), radius: radius * 0.6)
        case .full:
            content
                .shadow(color: color.opacity(0.8), radius: radius * 0.5)
                .shadow(color: color.opacity(0.45), radius: radius)
        }
    }
}

// MARK: - Glass

private struct GlassModifier: ViewModifier {
    @EnvironmentObject private var themes: ThemeStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let radius: CGFloat

    func body(content: Content) -> some View {
        let level = themes.effectiveEffects(reduceMotion: reduceMotion)
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        if level == .off {
            content.background(Color(.secondarySystemBackground), in: shape)
        } else {
            content
                .background(.ultraThinMaterial, in: shape)
                .overlay(
                    shape.strokeBorder(
                        LinearGradient(
                            colors: [.white.opacity(0.35), .white.opacity(0.05)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 0.8
                    )
                )
        }
    }
}

extension View {
    func neonGlow(_ color: Color, radius: CGFloat = 10) -> some View {
        modifier(NeonGlowModifier(color: color, radius: radius))
    }

    func glass(cornerRadius: CGFloat = KroRadius.card) -> some View {
        modifier(GlassModifier(radius: cornerRadius))
    }
}

// MARK: - Backdrop

/// Soft animated color field. Static gradient at "balanced", moving blobs only at "full".
struct AuroraBackdrop: View {
    @EnvironmentObject private var themes: ThemeStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private static let palette: [Color] = [
        Color(hex: "7A4FD6"), Color(hex: "00C2FF"), Color(hex: "FF4FA3")
    ]

    var body: some View {
        let level = themes.effectiveEffects(reduceMotion: reduceMotion)
        ZStack {
            Color(.systemBackground)
            switch level {
            case .off:
                EmptyView()
            case .balanced:
                LinearGradient(
                    colors: [themes.current.accent.opacity(0.25), Color(.systemBackground)],
                    startPoint: .top, endPoint: .bottom
                )
            case .full:
                TimelineView(.animation(minimumInterval: 1.0 / 24.0)) { context in
                    blobs(time: context.date.timeIntervalSinceReferenceDate)
                }
            }
        }
        .ignoresSafeArea()
    }

    private func blobs(time: Double) -> some View {
        GeometryReader { geo in
            ZStack {
                blob(themes.current.accent, geo.size, time, phase: 0)
                blob(Self.palette[0], geo.size, time, phase: 2.1)
                blob(Self.palette[1], geo.size, time, phase: 4.2)
                blob(Self.palette[2], geo.size, time, phase: 5.6)
            }
            .blur(radius: 70)
        }
    }

    private func blob(_ color: Color, _ size: CGSize, _ time: Double, phase: Double) -> some View {
        let x = size.width * (0.5 + 0.32 * sin(time * 0.22 + phase))
        let y = size.height * (0.45 + 0.28 * cos(time * 0.17 + phase * 1.3))
        return Circle()
            .fill(color.opacity(0.38))
            .frame(width: size.width * 0.7, height: size.width * 0.7)
            .position(x: x, y: y)
    }
}

// MARK: - Transitions

/// Blur + scale + fade, used for new messages and login steps.
struct KroBlurTransition: Transition {
    func body(content: Content, phase: TransitionPhase) -> some View {
        content
            .blur(radius: phase.isIdentity ? 0 : 12)
            .opacity(phase.isIdentity ? 1 : 0)
            .scaleEffect(phase.isIdentity ? 1 : 0.94)
    }
}

// MARK: - Haptics

enum Haptics {
    static func tap() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    static func success() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }
}
